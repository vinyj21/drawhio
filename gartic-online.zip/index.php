<?php
/**
 * Drawhio - Suporte Oficial para Hospedagens PHP (InfinityFree, cPanel, Hostinger)
 * Este arquivo garante que o jogo carregue mesmo se a hospedagem priorizar index.php.
 */
if (file_exists(__DIR__ . '/index.html')) {
    readfile(__DIR__ . '/index.html');
} else {
    echo "Erro: index.html não encontrado no diretório.";
}
exit;
?>

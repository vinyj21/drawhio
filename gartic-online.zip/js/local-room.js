// =========================================================
// DRAWHIO - MOTOR DE SALA LOCAL / OFFLINE (LOCAL ROOM ENGINE)
// =========================================================
// Permite criar salas, jogar com robôs e gerenciar partidas
// diretamente no navegador em hospedagens estáticas (InfinityFree, GitHub Pages)
// sem necessidade imediata de um servidor backend Node.js!

(function() {
  // Despachador de eventos local desacoplado
  const localDispatcher = {
    listeners: {},
    on(event, fn) {
      if (!this.listeners[event]) this.listeners[event] = [];
      this.listeners[event].push(fn);
    },
    emit(event, data) {
      if (this.listeners[event]) {
        this.listeners[event].forEach(fn => {
          try { fn(data); } catch (e) { console.error(`[LocalDispatcher Error] ${event}:`, e); }
        });
      }
    }
  };

  window.localDispatcher = localDispatcher;

  class LocalGameRoom {
    constructor() {
      this.isActive = false;
      this.roomCode = "LOCAL-1";
      this.state = "LOBBY";
      this.hostPlayer = null;
      this.botPlayer = null;
      this.players = [];
      this.settings = {
        roundDuration: 70,
        pointsGoal: 120,
        totalRounds: 3,
        category: "todos",
        gameMode: "classico"
      };
      this.customWords = [];
      this.scores = {};
      this.roundScores = {};
      this.currentRound = 1;
      this.currentDrawerId = null;
      this.selectedWord = null;
      this.turnOrder = [];
      this.turnIndex = 0;
      this.timerInterval = null;
      this.timeRemaining = 0;
      this.botChatTimeouts = [];
      this.botDrawInterval = null;
      this.guessedPlayers = new Set();
    }

    createRoom(player, options = {}) {
      this.reset();
      this.isActive = true;
      this.roomCode = "ROBO-" + Math.floor(100 + Math.random() * 900);
      this.state = "LOBBY";
      this.hostPlayer = {
        id: "human-host",
        name: player.name || "Artista",
        avatar: player.avatar || { id: "nb", icon: "icon_nb.png" },
        isHost: true,
        isBot: false,
        score: 0
      };
      this.botPlayer = {
        id: "bot-pintor",
        name: "Robô Pintor",
        avatar: { id: "nb", icon: "icon_nb.png" },
        isHost: false,
        isBot: true,
        score: 0
      };
      this.players = [this.hostPlayer, this.botPlayer];
      this.scores = {
        "human-host": 0,
        "bot-pintor": 0
      };
      this.roundScores = {
        "human-host": 0,
        "bot-pintor": 0
      };

      this.settings = {
        roundDuration: parseInt(options.roundDuration) || 70,
        pointsGoal: parseInt(options.pointsGoal) || 120,
        totalRounds: parseInt(options.totalRounds) || 3,
        category: options.category || "todos",
        gameMode: options.gameMode || "classico"
      };
      this.customWords = options.customWords || [];

      this.emitRoomState();
      return { success: true, roomCode: this.roomCode };
    }

    emitRoomState() {
      const stateObj = {
        roomCode: this.roomCode,
        state: this.state,
        hostId: "human-host",
        myId: "human-host",
        isHost: true,
        currentRound: this.currentRound,
        totalRounds: this.settings.totalRounds,
        pointsGoal: this.settings.pointsGoal,
        currentDrawerId: this.currentDrawerId,
        wordChoices: this.state === "SELECTING_WORD" && this.currentDrawerId === "human-host" ? this.wordChoices : [],
        maskedWord: this.selectedWord ? (this.currentDrawerId === "human-host" ? this.selectedWord.word : this.getMaskedWord()) : "",
        selectedWord: (this.currentDrawerId === "human-host" && this.selectedWord) ? this.selectedWord : null,
        players: this.players.map(p => ({
          id: p.id,
          name: p.name,
          avatar: p.avatar,
          score: this.scores[p.id] || 0,
          roundScore: this.roundScores[p.id] || 0,
          isHost: p.id === "human-host",
          isBot: p.isBot,
          isDrawing: p.id === this.currentDrawerId,
          hasGuessed: this.guessedPlayers.has(p.id)
        })),
        settings: this.settings,
        settingsSummary: {
          durationText: `${this.settings.roundDuration}s`,
          roundsText: `${this.settings.totalRounds} rodadas`,
          goalText: `${this.settings.pointsGoal} pts`,
          categoryText: this.settings.category,
          modeText: this.settings.gameMode
        }
      };

      localDispatcher.emit("room_state", stateObj);
    }

    startGame() {
      if (!this.isActive) return { success: false, reason: "Sala inativa" };
      this.state = "SELECTING_WORD";
      this.currentRound = 1;
      this.turnOrder = ["human-host", "bot-pintor"];
      this.turnIndex = 0;
      this.startTurn();
      return { success: true };
    }

    startTurn() {
      this.clearTimers();
      this.guessedPlayers.clear();
      this.roundScores = { "human-host": 0, "bot-pintor": 0 };
      this.currentDrawerId = this.turnOrder[this.turnIndex];

      if (this.currentDrawerId === "human-host") {
        // Vez do Jogador Humano escolher palavra
        this.state = "SELECTING_WORD";
        const words = window.DRAWHIO_WORDS
          ? window.DRAWHIO_WORDS.getRandomWordChoices(this.settings.category, this.customWords)
          : [
              { word: "Pizza", hint: "Comida italiana redonda", category: "alimentos" },
              { word: "Cachorro", hint: "Melhor amigo do homem", category: "animais" },
              { word: "Carro", hint: "Veículo de 4 rodas", category: "objetos" }
            ];
        this.wordChoices = words;
        this.emitRoomState();

        // Alerta sonoro / toast
        localDispatcher.emit("chat_message", {
          type: "system",
          text: `🔔 Rodada ${this.currentRound}: Sua vez de desenhar! Escolha uma das 3 palavras.`
        });
      } else {
        // Vez do Robô desenhar
        this.state = "DRAWING";
        const words = window.DRAWHIO_WORDS
          ? window.DRAWHIO_WORDS.getRandomWordChoices(this.settings.category, this.customWords)
          : [{ word: "Sol", hint: "Estrela do dia", category: "natureza" }];
        this.selectedWord = words[0];
        this.wordChoices = [];
        this.emitRoomState();

        localDispatcher.emit("clear_canvas");
        localDispatcher.emit("chat_message", {
          type: "system",
          text: `🤖 Vez do Robô Pintor desenhar! Tente adivinhar a palavra no chat.`
        });

        this.startDrawingTimer();
        this.startBotDrawing();
      }
    }

    chooseWord(word) {
      if (this.state !== "SELECTING_WORD" || this.currentDrawerId !== "human-host") return;
      let wordObj = this.wordChoices.find(w => (typeof w === "string" ? w : w.word) === word);
      if (!wordObj) {
        wordObj = { word: word, hint: "Palavra selecionada", category: "geral" };
      }
      this.selectedWord = wordObj;
      this.state = "DRAWING";
      this.emitRoomState();

      localDispatcher.emit("clear_canvas");
      localDispatcher.emit("chat_message", {
        type: "system",
        text: `🎨 Você escolheu desenhar "${this.selectedWord.word}". Comece a desenhar na tela!`
      });

      this.startDrawingTimer();
      this.scheduleBotGuesses();
    }

    startDrawingTimer() {
      this.timeRemaining = this.settings.roundDuration;
      localDispatcher.emit("timer_update", { timeRemaining: this.timeRemaining, totalTime: this.settings.roundDuration });

      this.timerInterval = setInterval(() => {
        this.timeRemaining--;
        localDispatcher.emit("timer_update", { timeRemaining: this.timeRemaining, totalTime: this.settings.roundDuration });

        if (this.selectedWord && this.currentDrawerId !== "human-host") {
          // Atualizar dica mascarada gradualmente
          this.emitRoomState();
        }

        if (this.timeRemaining <= 0) {
          this.endRound("Tempo esgotado!");
        }
      }, 1000);
    }

    scheduleBotGuesses() {
      this.botChatTimeouts.forEach(t => clearTimeout(t));
      this.botChatTimeouts = [];

      const targetWord = this.selectedWord ? this.selectedWord.word : "desenho";

      // 1. Comentário inicial do robô (7s)
      this.botChatTimeouts.push(setTimeout(() => {
        if (this.state !== "DRAWING") return;
        const hints = [
          "Hummm, traços interessantes...",
          "Estou prestando atenção!",
          "Será que é um objeto?",
          "Interessante, continue desenhando!"
        ];
        const msg = hints[Math.floor(Math.random() * hints.length)];
        localDispatcher.emit("chat_message", {
          type: "player",
          sender: "Robô Pintor",
          text: msg,
          avatar: { id: "nb", icon: "icon_nb.png" }
        });
      }, 7000));

      // 2. Chute errado / engraçado do robô (16s)
      this.botChatTimeouts.push(setTimeout(() => {
        if (this.state !== "DRAWING") return;
        const wrongGuesses = ["um gato?", "uma casa?", "um avião?", "uma maçã?"];
        const guess = wrongGuesses[Math.floor(Math.random() * wrongGuesses.length)];
        localDispatcher.emit("chat_message", {
          type: "player",
          sender: "Robô Pintor",
          text: guess,
          avatar: { id: "nb", icon: "icon_nb.png" }
        });
      }, 16000));

      // 3. Acerto triunfal do robô (24s)
      this.botChatTimeouts.push(setTimeout(() => {
        if (this.state !== "DRAWING") return;
        this.handleBotCorrectGuess(targetWord);
      }, 24000));
    }

    handleBotCorrectGuess(word) {
      if (this.guessedPlayers.has("bot-pintor")) return;
      this.guessedPlayers.add("bot-pintor");

      this.scores["bot-pintor"] = (this.scores["bot-pintor"] || 0) + 10;
      this.scores["human-host"] = (this.scores["human-host"] || 0) + 2;
      this.roundScores["bot-pintor"] = 10;
      this.roundScores["human-host"] = 2;

      localDispatcher.emit("player_guessed", {
        playerId: "bot-pintor",
        playerName: "Robô Pintor",
        points: 10,
        drawerPoints: 2,
        isFirstGuesser: true
      });

      localDispatcher.emit("chat_message", {
        type: "correct",
        sender: "Robô Pintor",
        text: `acertou a palavra: "${word}"!`
      });

      this.emitRoomState();

      // Finalizar rodada após acerto
      setTimeout(() => {
        this.endRound(`Robô Pintor acertou a palavra "${word}"!`);
      }, 2000);
    }

    // Desenho procedural animado do robô quando for a vez dele
    startBotDrawing() {
      if (this.botDrawInterval) clearInterval(this.botDrawInterval);

      // Traços geométricos dinâmicos
      let step = 0;
      const strokes = [
        { type: "circle", x: 300, y: 220, r: 80, color: "#EF4444", size: 6 },
        { type: "circle", x: 260, y: 200, r: 12, color: "#18181B", size: 4 },
        { type: "circle", x: 340, y: 200, r: 12, color: "#18181B", size: 4 },
        { type: "line", x1: 260, y1: 250, x2: 340, y2: 250, color: "#18181B", size: 6 },
        { type: "line", x1: 300, y1: 120, x2: 300, y2: 60, color: "#FBBF24", size: 6 },
        { type: "line", x1: 400, y1: 160, x2: 460, y2: 120, color: "#FBBF24", size: 6 },
        { type: "line", x1: 200, y1: 160, x2: 140, y2: 120, color: "#FBBF24", size: 6 },
        { type: "line", x1: 400, y1: 280, x2: 460, y2: 320, color: "#FBBF24", size: 6 },
        { type: "line", x1: 200, y1: 280, x2: 140, y2: 320, color: "#FBBF24", size: 6 }
      ];

      this.botDrawInterval = setInterval(() => {
        if (this.state !== "DRAWING" || step >= strokes.length) {
          clearInterval(this.botDrawInterval);
          return;
        }

        const s = strokes[step];
        if (s.type === "circle") {
          localDispatcher.emit("draw_action", {
            type: "shape",
            shape: "circle",
            x: s.x - s.r,
            y: s.y - s.r,
            w: s.r * 2,
            h: s.r * 2,
            color: s.color,
            size: s.size,
            filled: false
          });
        } else if (s.type === "line") {
          localDispatcher.emit("draw_action", {
            type: "stroke",
            points: [
              { x: s.x1 / 800, y: s.y1 / 600 },
              { x: s.x2 / 800, y: s.y2 / 600 }
            ],
            color: s.color,
            size: s.size,
            tool: "brush"
          });
        }
        step++;
      }, 700);
    }

    handlePlayerGuess(text) {
      if (this.state !== "DRAWING") return;
      const guess = String(text || "").trim();
      if (!guess) return;

      const targetWord = this.selectedWord ? this.selectedWord.word : "";

      // Se for a vez do jogador desenhar, chat é normal
      if (this.currentDrawerId === "human-host") {
        localDispatcher.emit("chat_message", {
          type: "player",
          sender: this.hostPlayer.name,
          text: guess,
          avatar: this.hostPlayer.avatar
        });
        return;
      }

      // Se o jogador já acertou nesta rodada
      if (this.guessedPlayers.has("human-host")) {
        localDispatcher.emit("chat_message", {
          type: "player",
          sender: this.hostPlayer.name,
          text: guess,
          avatar: this.hostPlayer.avatar
        });
        return;
      }

      const normGuess = window.DRAWHIO_WORDS ? window.DRAWHIO_WORDS.normalizeWord(guess) : guess.toLowerCase().trim();
      const normTarget = window.DRAWHIO_WORDS ? window.DRAWHIO_WORDS.normalizeWord(targetWord) : targetWord.toLowerCase().trim();

      if (normGuess === normTarget) {
        // ACERTO DO JOGADOR!
        this.guessedPlayers.add("human-host");
        this.scores["human-host"] = (this.scores["human-host"] || 0) + 10;
        this.scores["bot-pintor"] = (this.scores["bot-pintor"] || 0) + 2;
        this.roundScores["human-host"] = 10;
        this.roundScores["bot-pintor"] = 2;

        localDispatcher.emit("player_guessed", {
          playerId: "human-host",
          playerName: this.hostPlayer.name,
          points: 10,
          drawerPoints: 2,
          isFirstGuesser: true
        });

        localDispatcher.emit("chat_message", {
          type: "correct",
          sender: this.hostPlayer.name,
          text: `acertou a palavra: "${targetWord}"!`
        });

        this.emitRoomState();

        setTimeout(() => {
          this.endRound(`Você acertou a palavra "${targetWord}"!`);
        }, 1800);
      } else if (window.DRAWHIO_WORDS && window.DRAWHIO_WORDS.isCloseGuess(guess, targetWord)) {
        localDispatcher.emit("close_guess", {
          sender: this.hostPlayer.name,
          guess: guess
        });
        localDispatcher.emit("chat_message", {
          type: "close",
          sender: "Sistema",
          text: `"${guess}" está muito perto da resposta!`
        });
      } else {
        localDispatcher.emit("chat_message", {
          type: "player",
          sender: this.hostPlayer.name,
          text: guess,
          avatar: this.hostPlayer.avatar
        });
      }
    }

    getMaskedWord() {
      if (!this.selectedWord) return "";
      const word = this.selectedWord.word;
      if (!window.DRAWHIO_WORDS) return word.split("").map(() => "_").join(" ");
      const progress = 1 - (this.timeRemaining / (this.settings.roundDuration || 70));
      return window.DRAWHIO_WORDS.getMaskedHint(word, progress);
    }

    endRound(reason = "") {
      this.clearTimers();
      this.state = "ROUND_END";

      const wordRevealed = this.selectedWord ? this.selectedWord.word : "";
      const hintRevealed = this.selectedWord ? this.selectedWord.hint : "";

      const roundSummary = {
        word: wordRevealed,
        hint: hintRevealed,
        reason: reason,
        players: this.players.map(p => ({
          id: p.id,
          name: p.name,
          avatar: p.avatar,
          score: this.scores[p.id] || 0,
          pointsEarned: this.roundScores[p.id] || 0
        }))
      };

      this.emitRoomState();
      localDispatcher.emit("round_ended", roundSummary);

      // Verificar meta de pontos
      const maxScore = Math.max(this.scores["human-host"] || 0, this.scores["bot-pintor"] || 0);
      const isGameOver = maxScore >= this.settings.pointsGoal || (this.currentRound >= this.settings.totalRounds * 2);

      setTimeout(() => {
        if (!this.isActive) return;

        if (isGameOver) {
          this.state = "GAME_OVER";
          const ranking = [...this.players].sort((a, b) => (this.scores[b.id] || 0) - (this.scores[a.id] || 0));
          this.emitRoomState();
          localDispatcher.emit("game_over", {
            ranking: ranking.map((p, idx) => ({
              rank: idx + 1,
              id: p.id,
              name: p.name,
              avatar: p.avatar,
              score: this.scores[p.id] || 0
            }))
          });
        } else {
          // Próximo turno
          this.turnIndex = (this.turnIndex + 1) % this.turnOrder.length;
          if (this.turnIndex === 0) {
            this.currentRound++;
          }
          this.startTurn();
        }
      }, 4000);
    }

    restartToLobby() {
      this.clearTimers();
      this.state = "LOBBY";
      this.scores = { "human-host": 0, "bot-pintor": 0 };
      this.roundScores = { "human-host": 0, "bot-pintor": 0 };
      this.currentRound = 1;
      this.currentDrawerId = null;
      this.selectedWord = null;
      this.emitRoomState();
    }

    clearTimers() {
      if (this.timerInterval) clearInterval(this.timerInterval);
      if (this.botDrawInterval) clearInterval(this.botDrawInterval);
      this.botChatTimeouts.forEach(t => clearTimeout(t));
      this.botChatTimeouts = [];
      this.timerInterval = null;
      this.botDrawInterval = null;
    }

    reset() {
      this.clearTimers();
      this.isActive = false;
      this.state = "LOBBY";
      this.players = [];
    }
  }

  window.LocalGameRoom = new LocalGameRoom();
})();

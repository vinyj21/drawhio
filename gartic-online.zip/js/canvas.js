// =========================================================
// DRAWHIO - MOTOR DE DESENHO ULTRA-SUAVE (CANVAS ENGINE 2.0)
// =========================================================

class DrawingBoard {
  constructor(canvasElement, options = {}) {
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });

    // Resolução lógica interna fixa (1200x720 para sincronização perfeita multi-resolução)
    this.VIRTUAL_WIDTH = 1200;
    this.VIRTUAL_HEIGHT = 720;
    this.canvas.width = this.VIRTUAL_WIDTH;
    this.canvas.height = this.VIRTUAL_HEIGHT;

    // Configurações globais de traçado para suavidade máxima
    this.ctx.lineCap = "round";
    this.ctx.lineJoin = "round";

    // Estado da ferramenta
    this.currentTool = "brush"; // "brush", "eraser", "fill", "pipette", "rect", "circle", "line"
    this.previousTool = "brush";
    this.currentColor = "#18181B";
    this.currentSize = 9;
    this.isDrawing = false;
    this.isDrawingShape = false;
    this.shapeStart = null;
    this.shapeSnapshot = null;
    this.isInteractive = false; // Se o jogador local é o desenhista

    // Pontos do traço atual e ponto médio anterior para curvas Bézier contínuas
    this.currentStroke = [];
    this.lastMidPoint = null;

    // Pilha de ações local para Desfazer / Refazer
    this.history = [];
    this.redoStack = [];

    // Callback de envio via socket e eventos
    this.onActionEmit = options.onActionEmit || (() => {});
    this.onCursorEmit = options.onCursorEmit || null;
    this.onColorPicked = options.onColorPicked || null;
    this.lastCursorEmit = 0;

    // Elemento do cursor visual dinâmico (Brush Ring Cursor)
    this.cursorRing = null;
    this.createCursorRing();

    this.initEvents();
    this.initKeyboardShortcuts();
    this.clearCanvas(false);
  }

  // Criação do cursor de anel que mostra o tamanho e cor exatos do pincel
  createCursorRing() {
    this.cursorRing = document.createElement("div");
    this.cursorRing.className = "canvas-brush-cursor";
    this.cursorRing.style.display = "none";
    this.cursorRing.style.position = "absolute";
    this.cursorRing.style.pointerEvents = "none";
    this.cursorRing.style.borderRadius = "50%";
    this.cursorRing.style.zIndex = "1000";
    const parent = this.canvas.parentElement || document.body;
    parent.style.position = "relative";
    parent.appendChild(this.cursorRing);
  }

  updateCursorRing(clientX, clientY) {
    if (!this.cursorRing || !this.isInteractive) return;
    if (this.currentTool === "pipette") {
      this.cursorRing.style.display = "none";
      return;
    }

    const rect = this.canvas.getBoundingClientRect();
    const scale = rect.width / this.VIRTUAL_WIDTH;
    const screenDiameter = Math.max(6, this.currentSize * scale);

    this.cursorRing.style.width = `${screenDiameter}px`;
    this.cursorRing.style.height = `${screenDiameter}px`;
    this.cursorRing.style.left = `${clientX - rect.left - screenDiameter / 2}px`;
    this.cursorRing.style.top = `${clientY - rect.top - screenDiameter / 2}px`;
    this.cursorRing.style.backgroundColor = (this.currentTool === "eraser") 
      ? "rgba(255, 255, 255, 0.7)" 
      : `${this.currentColor}33`; // 20% de opacidade da cor do pincel
    this.cursorRing.style.display = "block";
  }

  hideCursorRing() {
    if (this.cursorRing) {
      this.cursorRing.style.display = "none";
    }
  }

  setInteractive(enabled) {
    this.isInteractive = enabled;
    if (enabled) {
      this.canvas.style.cursor = "crosshair";
    } else {
      this.canvas.style.cursor = "default";
      this.isDrawing = false;
      this.isDrawingShape = false;
      this.hideCursorRing();
    }
  }

  setTool(tool) {
    if (this.currentTool !== "pipette") {
      this.previousTool = this.currentTool;
    }
    this.currentTool = tool;
    if (this.canvas) {
      this.canvas.style.cursor = (tool === "pipette") ? "crosshair" : "crosshair";
    }
  }

  setColor(hex) {
    this.currentColor = hex;
    if (this.currentTool === "eraser") {
      this.currentTool = "brush";
    }
  }

  setSize(size) {
    this.currentSize = Math.max(2, Math.min(80, size));
  }

  // Capturar cor de qualquer pixel do canvas (Pipeta / Conta-gotas - tecla I)
  pickColor(x, y) {
    const px = Math.floor(Math.max(0, Math.min(this.VIRTUAL_WIDTH - 1, x)));
    const py = Math.floor(Math.max(0, Math.min(this.VIRTUAL_HEIGHT - 1, y)));
    const pixel = this.ctx.getImageData(px, py, 1, 1).data;
    const r = pixel[0].toString(16).padStart(2, "0");
    const g = pixel[1].toString(16).padStart(2, "0");
    const b = pixel[2].toString(16).padStart(2, "0");
    const hex = `#${r}${g}${b}`.toUpperCase();
    this.setColor(hex);
    if (typeof this.onColorPicked === "function") {
      this.onColorPicked(hex);
    }
    return hex;
  }

  // Desenho de Formas Geométricas Básicas (v1.4)
  drawShape(shape, x1, y1, x2, y2, color, size) {
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = "round";
    this.ctx.lineJoin = "round";

    if (shape === "rect") {
      const left = Math.min(x1, x2);
      const top = Math.min(y1, y2);
      const w = Math.abs(x2 - x1);
      const h = Math.abs(y2 - y1);
      this.ctx.beginPath();
      this.ctx.strokeRect(left, top, w, h);
    } else if (shape === "circle") {
      const cx = (x1 + x2) / 2;
      const cy = (y1 + y2) / 2;
      const rx = Math.max(1, Math.abs(x2 - x1) / 2);
      const ry = Math.max(1, Math.abs(y2 - y1) / 2);
      this.ctx.beginPath();
      this.ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      this.ctx.stroke();
    } else if (shape === "line") {
      this.ctx.beginPath();
      this.ctx.moveTo(x1, y1);
      this.ctx.lineTo(x2, y2);
      this.ctx.stroke();
    }
  }

  // Conversão de coordenadas tela -> resolução lógica interna 1200x720 com precisão sub-pixel
  getCanvasCoordinates(e) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.VIRTUAL_WIDTH / rect.width;
    const scaleY = this.VIRTUAL_HEIGHT / rect.height;

    const clientX = (e.clientX !== undefined) ? e.clientX : (e.touches && e.touches[0] ? e.touches[0].clientX : rect.left);
    const clientY = (e.clientY !== undefined) ? e.clientY : (e.touches && e.touches[0] ? e.touches[0].clientY : rect.top);

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }

  initEvents() {
    const handlePointerDown = (e) => {
      if (!this.isInteractive) return;
      // Permitir apenas botão principal (clique esquerdo ou toque)
      if (e.button !== undefined && e.button !== 0) return;
      e.preventDefault();

      try {
        this.canvas.setPointerCapture(e.pointerId);
      } catch (err) {}

      const pos = this.getCanvasCoordinates(e);

      // Pipeta / Conta-gotas (tecla I)
      if (this.currentTool === "pipette") {
        this.pickColor(pos.x, pos.y);
        this.setTool(this.previousTool || "brush");
        return;
      }

      // Balde de tinta
      if (this.currentTool === "fill") {
        this.executeFloodFill(pos.x, pos.y, this.currentColor, true);
        return;
      }

      // Formas geométricas: Retângulo, Círculo, Linha
      if (["rect", "circle", "line"].includes(this.currentTool)) {
        this.isDrawingShape = true;
        this.shapeStart = { x: pos.x, y: pos.y };
        this.shapeSnapshot = this.ctx.getImageData(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);
        return;
      }

      this.isDrawing = true;
      this.currentStroke = [pos];
      this.lastMidPoint = { x: pos.x, y: pos.y };

      const activeColor = (this.currentTool === "eraser") ? "#ffffff" : this.currentColor;
      // Desenha ponto inicial suave
      this.renderPoint(pos.x, pos.y, activeColor, this.currentSize);
      this.updateCursorRing(e.clientX, e.clientY);
    };

    const handlePointerMove = (e) => {
      if (!this.isInteractive) return;

      this.updateCursorRing(e.clientX, e.clientY);

      // Pré-visualização de formas geométricas em tempo real enquanto arrasta
      if (this.isDrawingShape && this.shapeStart && this.shapeSnapshot) {
        e.preventDefault();
        const pos = this.getCanvasCoordinates(e);
        this.ctx.putImageData(this.shapeSnapshot, 0, 0);

        let endX = pos.x;
        let endY = pos.y;

        // Mantendo a tecla Shift pressionada -> Proporções Perfeitas
        if (e.shiftKey) {
          if (this.currentTool === "rect" || this.currentTool === "circle") {
            const dx = endX - this.shapeStart.x;
            const dy = endY - this.shapeStart.y;
            const maxD = Math.max(Math.abs(dx), Math.abs(dy));
            endX = this.shapeStart.x + (dx >= 0 ? maxD : -maxD);
            endY = this.shapeStart.y + (dy >= 0 ? maxD : -maxD);
          } else if (this.currentTool === "line") {
            const dx = endX - this.shapeStart.x;
            const dy = endY - this.shapeStart.y;
            const angle = Math.atan2(dy, dx);
            const dist = Math.hypot(dx, dy);
            const snappedAngle = Math.round(angle / (Math.PI / 4)) * (Math.PI / 4);
            endX = this.shapeStart.x + Math.cos(snappedAngle) * dist;
            endY = this.shapeStart.y + Math.sin(snappedAngle) * dist;
          }
        }

        this.drawShape(this.currentTool, this.shapeStart.x, this.shapeStart.y, endX, endY, this.currentColor, this.currentSize);
        return;
      }

      if (!this.isDrawing) return;
      e.preventDefault();

      // Coletar todos os eventos intermediários se o navegador suportar (60Hz -> 120Hz/1000Hz gaming mice)
      const events = (typeof e.getCoalescedEvents === "function") 
        ? e.getCoalescedEvents() 
        : [e];

      const activeColor = (this.currentTool === "eraser") ? "#ffffff" : this.currentColor;

      for (const ev of events) {
        const pos = this.getCanvasCoordinates(ev);
        const lastP = this.currentStroke[this.currentStroke.length - 1];

        // Evita pontos repetidos idênticos
        if (lastP && Math.hypot(pos.x - lastP.x, pos.y - lastP.y) < 0.8) {
          continue;
        }

        this.currentStroke.push(pos);
        const len = this.currentStroke.length;

        if (len === 2) {
          const midX = (this.lastMidPoint.x + pos.x) / 2;
          const midY = (this.lastMidPoint.y + pos.y) / 2;
          this.drawLineSegment(this.lastMidPoint.x, this.lastMidPoint.y, midX, midY, activeColor, this.currentSize);
          this.lastMidPoint = { x: midX, y: midY };
        } else if (len > 2) {
          const pPrev = this.currentStroke[len - 2];
          const midX = (pPrev.x + pos.x) / 2;
          const midY = (pPrev.y + pos.y) / 2;

          this.drawQuadraticSegment(this.lastMidPoint.x, this.lastMidPoint.y, pPrev.x, pPrev.y, midX, midY, activeColor, this.currentSize);
          this.lastMidPoint = { x: midX, y: midY };
        }
      }

      // Transmissão do cursor para outros jogadores com throttle de ~35ms
      if (this.onCursorEmit) {
        const now = Date.now();
        if (now - this.lastCursorEmit > 35) {
          this.lastCursorEmit = now;
          const latestPos = this.currentStroke[this.currentStroke.length - 1];
          if (latestPos) {
            this.onCursorEmit({
              x: Math.max(0, Math.min(1, latestPos.x / this.VIRTUAL_WIDTH)),
              y: Math.max(0, Math.min(1, latestPos.y / this.VIRTUAL_HEIGHT))
            });
          }
        }
      }
    };

    const handlePointerUp = (e) => {
      if (!this.isInteractive) return;

      // Finalização de formas geométricas
      if (this.isDrawingShape && this.shapeStart && this.shapeSnapshot) {
        this.isDrawingShape = false;
        e.preventDefault();

        try {
          if (this.canvas.hasPointerCapture && this.canvas.hasPointerCapture(e.pointerId)) {
            this.canvas.releasePointerCapture(e.pointerId);
          }
        } catch (err) {}

        const pos = this.getCanvasCoordinates(e);
        this.ctx.putImageData(this.shapeSnapshot, 0, 0);

        let endX = pos.x;
        let endY = pos.y;

        if (e.shiftKey) {
          if (this.currentTool === "rect" || this.currentTool === "circle") {
            const dx = endX - this.shapeStart.x;
            const dy = endY - this.shapeStart.y;
            const maxD = Math.max(Math.abs(dx), Math.abs(dy));
            endX = this.shapeStart.x + (dx >= 0 ? maxD : -maxD);
            endY = this.shapeStart.y + (dy >= 0 ? maxD : -maxD);
          } else if (this.currentTool === "line") {
            const dx = endX - this.shapeStart.x;
            const dy = endY - this.shapeStart.y;
            const angle = Math.atan2(dy, dx);
            const dist = Math.hypot(dx, dy);
            const snappedAngle = Math.round(angle / (Math.PI / 4)) * (Math.PI / 4);
            endX = this.shapeStart.x + Math.cos(snappedAngle) * dist;
            endY = this.shapeStart.y + Math.sin(snappedAngle) * dist;
          }
        }

        if (Math.hypot(endX - this.shapeStart.x, endY - this.shapeStart.y) > 2) {
          this.drawShape(this.currentTool, this.shapeStart.x, this.shapeStart.y, endX, endY, this.currentColor, this.currentSize);

          const action = {
            type: "shape",
            shape: this.currentTool,
            x1: this.shapeStart.x,
            y1: this.shapeStart.y,
            x2: endX,
            y2: endY,
            color: this.currentColor,
            size: this.currentSize
          };

          this.history.push(action);
          this.redoStack = [];
          this.onActionEmit(action);
        }

        this.shapeStart = null;
        this.shapeSnapshot = null;
        return;
      }

      if (!this.isDrawing) return;
      e.preventDefault();
      this.isDrawing = false;

      try {
        if (this.canvas.hasPointerCapture && this.canvas.hasPointerCapture(e.pointerId)) {
          this.canvas.releasePointerCapture(e.pointerId);
        }
      } catch (err) {}

      if (this.currentStroke.length > 0) {
        // Conectar até o ponto final exato para nunca perder o final do traço
        const lastP = this.currentStroke[this.currentStroke.length - 1];
        const activeColor = (this.currentTool === "eraser") ? "#ffffff" : this.currentColor;

        if (this.lastMidPoint && this.currentStroke.length > 1) {
          this.drawLineSegment(this.lastMidPoint.x, this.lastMidPoint.y, lastP.x, lastP.y, activeColor, this.currentSize);
        }

        const action = {
          type: "stroke",
          tool: this.currentTool,
          color: activeColor,
          size: this.currentSize,
          points: this.currentStroke
        };

        this.history.push(action);
        this.redoStack = [];
        this.onActionEmit(action);
        this.currentStroke = [];
        this.lastMidPoint = null;
      }
    };

    this.canvas.addEventListener("pointerdown", handlePointerDown);
    this.canvas.addEventListener("pointermove", handlePointerMove);
    this.canvas.addEventListener("pointerup", handlePointerUp);
    this.canvas.addEventListener("pointercancel", handlePointerUp);
    this.canvas.addEventListener("pointerleave", () => this.hideCursorRing());
    this.canvas.addEventListener("pointerenter", (e) => {
      if (this.isInteractive) this.updateCursorRing(e.clientX, e.clientY);
    });

    // Mobile & Tablet: touch-action: none e gestos de múltiplos toques
    this.canvas.style.touchAction = "none";
    let touchStartTime = 0;
    let maxTouches = 0;
    let touchMoved = false;

    this.canvas.addEventListener("touchstart", (e) => {
      if (!this.isInteractive) return;
      maxTouches = Math.max(maxTouches, e.touches.length);

      if (e.touches.length >= 2) {
        // Cancelar desenho em andamento com 2+ dedos para evitar riscos indesejados
        if (this.isDrawing) {
          this.isDrawing = false;
          this.currentStroke = [];
          this.lastMidPoint = null;
          this.redrawFromHistory();
        }
        if (this.isDrawingShape && this.shapeSnapshot) {
          this.isDrawingShape = false;
          this.ctx.putImageData(this.shapeSnapshot, 0, 0);
          this.shapeStart = null;
          this.shapeSnapshot = null;
        }
      }

      if (e.touches.length === 1) {
        touchStartTime = Date.now();
        maxTouches = 1;
        touchMoved = false;
      }
      e.preventDefault();
    }, { passive: false });

    this.canvas.addEventListener("touchmove", (e) => {
      if (!this.isInteractive) return;
      if (e.touches.length > 1) {
        touchMoved = true;
      }
      e.preventDefault();
    }, { passive: false });

    this.canvas.addEventListener("touchend", (e) => {
      if (!this.isInteractive) return;
      const duration = Date.now() - touchStartTime;

      // Toque rápido com 2 dedos -> Desfazer (Undo)
      if (maxTouches === 2 && duration < 400 && !touchMoved) {
        this.undo(true);
      } else if (maxTouches === 3 && duration < 400 && !touchMoved) {
        // Toque rápido com 3 dedos -> Refazer (Redo)
        this.redo(true);
      }

      if (e.touches.length === 0) {
        maxTouches = 0;
        touchMoved = false;
      }
      e.preventDefault();
    }, { passive: false });
  }

  // Atalhos de teclado ergonômicos
  initKeyboardShortcuts() {
    window.addEventListener("keydown", (e) => {
      // Ignorar se estiver digitando no chat ou em qualquer input
      if (["INPUT", "TEXTAREA"].includes(e.target.tagName)) return;
      if (!this.isInteractive) return;

      // Ctrl+Z / Cmd+Z -> Desfazer
      if ((e.ctrlKey || e.metaKey) && (e.key === "z" || e.key === "Z") && !e.shiftKey) {
        e.preventDefault();
        this.undo(true);
        return;
      }

      // Ctrl+Y ou Ctrl+Shift+Z -> Refazer
      if (((e.ctrlKey || e.metaKey) && (e.key === "y" || e.key === "Y")) ||
          ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === "z" || e.key === "Z"))) {
        e.preventDefault();
        this.redo(true);
        return;
      }

      // Tecla B -> Pincel
      if (e.key === "b" || e.key === "B") {
        this.setTool("brush");
        const btn = document.getElementById("tool-brush");
        if (btn) btn.click();
      }

      // Tecla E -> Borracha
      if (e.key === "e" || e.key === "E") {
        this.setTool("eraser");
        const btn = document.getElementById("tool-eraser");
        if (btn) btn.click();
      }

      // Tecla G ou F -> Balde de tinta (Fill)
      if (e.key === "g" || e.key === "G" || e.key === "f" || e.key === "F") {
        this.setTool("fill");
        const btn = document.getElementById("tool-fill");
        if (btn) btn.click();
      }

      // Tecla C -> Limpar Tela
      if (e.key === "c" || e.key === "C") {
        this.clearCanvas(true);
      }

      // Tecla I -> Pipeta / Conta-gotas
      if (e.key === "i" || e.key === "I") {
        this.setTool("pipette");
        const btn = document.getElementById("tool-pipette");
        if (btn) btn.click();
      }

      // Teclas 1, 2, 3, 4 -> Tamanhos de pincel
      if (["1", "2", "3", "4"].includes(e.key)) {
        const idx = parseInt(e.key) - 1;
        const sizeBtns = document.querySelectorAll(".brush-dot-btn");
        if (sizeBtns[idx]) sizeBtns[idx].click();
      }
    });
  }

  // Traçado direto de reta suave
  drawLineSegment(x1, y1, x2, y2, color, size) {
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = "round";
    this.ctx.lineJoin = "round";

    this.ctx.beginPath();
    this.ctx.moveTo(x1, y1);
    this.ctx.lineTo(x2, y2);
    this.ctx.stroke();
  }

  // Traçado quadrático suave
  drawQuadraticSegment(x0, y0, cx, cy, x1, y1, color, size) {
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = "round";
    this.ctx.lineJoin = "round";

    this.ctx.beginPath();
    this.ctx.moveTo(x0, y0);
    this.ctx.quadraticCurveTo(cx, cy, x1, y1);
    this.ctx.stroke();
  }

  // Ponto ou toque único
  renderPoint(x, y, color, size) {
    this.ctx.fillStyle = color;
    this.ctx.beginPath();
    this.ctx.arc(x, y, Math.max(1, size / 2), 0, Math.PI * 2);
    this.ctx.fill();
  }

  // Renderização completa do traço (usada para replays, histórico e recepção remota de outros jogadores)
  renderFullStroke(stroke) {
    const points = stroke.points;
    if (!points || points.length === 0) return;

    const color = stroke.color || "#18181B";
    const size = stroke.size || 9;

    if (points.length === 1) {
      this.renderPoint(points[0].x, points[0].y, color, size);
      return;
    }

    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = "round";
    this.ctx.lineJoin = "round";

    this.ctx.beginPath();
    this.ctx.moveTo(points[0].x, points[0].y);

    for (let i = 1; i < points.length; i++) {
      const pPrev = points[i - 1];
      const pCurr = points[i];
      const midX = (pPrev.x + pCurr.x) / 2;
      const midY = (pPrev.y + pCurr.y) / 2;

      if (i === 1) {
        this.ctx.lineTo(midX, midY);
      } else {
        this.ctx.quadraticCurveTo(pPrev.x, pPrev.y, midX, midY);
      }
    }

    const lastPoint = points[points.length - 1];
    this.ctx.lineTo(lastPoint.x, lastPoint.y);
    this.ctx.stroke();
  }

  // Algoritmo otimizado de Balde de Tinta (Flood Fill) com tolerância anti-aliasing
  executeFloodFill(startX, startY, fillHex, emit = true) {
    startX = Math.round(startX);
    startY = Math.round(startY);

    if (startX < 0 || startX >= this.VIRTUAL_WIDTH || startY < 0 || startY >= this.VIRTUAL_HEIGHT) return;

    const imgData = this.ctx.getImageData(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);
    const data = imgData.data;

    const fillColor = this.hexToRgba(fillHex);
    const startIdx = (startY * this.VIRTUAL_WIDTH + startX) * 4;
    const targetR = data[startIdx];
    const targetG = data[startIdx + 1];
    const targetB = data[startIdx + 2];
    const targetA = data[startIdx + 3];

    // Se a cor de destino for idêntica à cor de preenchimento, não precisa preencher
    if (this.colorMatch(targetR, targetG, targetB, targetA, fillColor.r, fillColor.g, fillColor.b, 255, 12)) {
      return;
    }

    const tolerance = 38; // Tolerância para bordas anti-aliased
    const pixelStack = [[startX, startY]];
    const width = this.VIRTUAL_WIDTH;
    const height = this.VIRTUAL_HEIGHT;
    const visited = new Uint8Array(width * height);

    while (pixelStack.length > 0) {
      const [x, y] = pixelStack.pop();
      let currentY = y;
      let idx = (currentY * width + x) * 4;

      while (currentY >= 0 && this.colorMatch(data[idx], data[idx + 1], data[idx + 2], data[idx + 3], targetR, targetG, targetB, targetA, tolerance)) {
        currentY--;
        idx -= width * 4;
      }

      currentY++;
      idx += width * 4;

      let reachLeft = false;
      let reachRight = false;

      while (currentY < height && this.colorMatch(data[idx], data[idx + 1], data[idx + 2], data[idx + 3], targetR, targetG, targetB, targetA, tolerance)) {
        const pIdx = currentY * width + x;
        if (visited[pIdx]) break;
        visited[pIdx] = 1;

        data[idx] = fillColor.r;
        data[idx + 1] = fillColor.g;
        data[idx + 2] = fillColor.b;
        data[idx + 3] = 255;

        if (x > 0) {
          const leftIdx = idx - 4;
          if (this.colorMatch(data[leftIdx], data[leftIdx + 1], data[leftIdx + 2], data[leftIdx + 3], targetR, targetG, targetB, targetA, tolerance)) {
            if (!reachLeft) {
              pixelStack.push([x - 1, currentY]);
              reachLeft = true;
            }
          } else {
            reachLeft = false;
          }
        }

        if (x < width - 1) {
          const rightIdx = idx + 4;
          if (this.colorMatch(data[rightIdx], data[rightIdx + 1], data[rightIdx + 2], data[rightIdx + 3], targetR, targetG, targetB, targetA, tolerance)) {
            if (!reachRight) {
              pixelStack.push([x + 1, currentY]);
              reachRight = true;
            }
          } else {
            reachRight = false;
          }
        }

        currentY++;
        idx += width * 4;
      }
    }

    this.ctx.putImageData(imgData, 0, 0);

    const action = { type: "fill", x: startX, y: startY, color: fillHex };
    this.history.push(action);
    this.redoStack = [];

    if (emit) {
      this.onActionEmit(action);
    }
  }

  colorMatch(r1, g1, b1, a1, r2, g2, b2, a2, tolerance = 0) {
    return Math.abs(r1 - r2) <= tolerance &&
           Math.abs(g1 - g2) <= tolerance &&
           Math.abs(b1 - b2) <= tolerance &&
           Math.abs(a1 - a2) <= tolerance;
  }

  hexToRgba(hex) {
    let c = hex.replace("#", "");
    if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
    const num = parseInt(c, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
  }

  renderBackgroundWatermark() {
    // A marca d'água oficial 'wtmk' do usuário é exibida em overlay HTML dedicado (.canvas-watermark > img),
    // garantindo fidelidade visual em alta resolução sem interferir no preenchimento flood fill ou traços.
  }

  // Limpar Tela
  clearCanvas(emit = true) {
    this.ctx.fillStyle = "#ffffff";
    this.ctx.fillRect(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);
    this.renderBackgroundWatermark();
    this.currentStroke = [];
    this.lastMidPoint = null;

    if (emit) {
      const action = { type: "clear" };
      this.history.push(action);
      this.redoStack = [];
      this.onActionEmit(action);
    }
  }

  // Desfazer (Undo)
  undo(emit = true) {
    if (this.history.length === 0) return;
    const popped = this.history.pop();
    this.redoStack.push(popped);
    this.redrawFromHistory();
    if (emit) this.onActionEmit({ type: "undo" });
  }

  // Refazer (Redo)
  redo(emit = true) {
    if (this.redoStack.length === 0) return;
    const action = this.redoStack.pop();
    this.applyAction(action, false);
    this.history.push(action);
    if (emit) this.onActionEmit(action);
  }

  redrawFromHistory() {
    this.ctx.fillStyle = "#ffffff";
    this.ctx.fillRect(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);
    this.renderBackgroundWatermark();
    for (const action of this.history) this.applyAction(action, false);
  }

  // Aplicar ação remota ou do histórico
  applyAction(action, addToHistory = true) {
    if (!action) return;

    if (action.type === "stroke") {
      this.renderFullStroke(action);
    } else if (action.type === "shape") {
      this.drawShape(action.shape, action.x1, action.y1, action.x2, action.y2, action.color, action.size);
    } else if (action.type === "fill") {
      this.executeFloodFill(action.x, action.y, action.color, false);
    } else if (action.type === "clear") {
      this.ctx.fillStyle = "#ffffff";
      this.ctx.fillRect(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);
      this.renderBackgroundWatermark();
      this.history = [];
      this.redoStack = [];
      this.currentStroke = [];
      this.lastMidPoint = null;
      return;
    } else if (action.type === "undo") {
      this.history.pop();
      this.redrawFromHistory();
      return;
    }

    if (addToHistory) {
      this.history.push(action);
    }
  }

  // Carregar histórico inteiro de uma rodada em andamento
  loadHistory(historyActions) {
    this.history = [];
    this.redoStack = [];
    this.currentStroke = [];
    this.lastMidPoint = null;
    this.ctx.fillStyle = "#ffffff";
    this.ctx.fillRect(0, 0, this.VIRTUAL_WIDTH, this.VIRTUAL_HEIGHT);

    if (Array.isArray(historyActions)) {
      for (const action of historyActions) {
        this.applyAction(action, true);
      }
    }
  }

  // Reprodução acelerada do desenho em 5 segundos (Timelapse Replay - v1.4)
  static playTimelapse(targetCanvas, historyActions, durationMs = 5000, onStep = null, onComplete = null) {
    if (!targetCanvas || !Array.isArray(historyActions) || historyActions.length === 0) {
      if (typeof onComplete === "function") onComplete();
      return { cancel: () => {} };
    }

    const tCtx = targetCanvas.getContext("2d");
    const width = targetCanvas.width;
    const height = targetCanvas.height;
    const scaleX = width / 1200;
    const scaleY = height / 720;

    tCtx.fillStyle = "#ffffff";
    tCtx.fillRect(0, 0, width, height);
    tCtx.lineCap = "round";
    tCtx.lineJoin = "round";

    const totalSteps = historyActions.length;
    const stepInterval = Math.max(16, durationMs / totalSteps);
    let currentIndex = 0;
    let cancelled = false;

    const interval = setInterval(() => {
      if (cancelled || currentIndex >= totalSteps) {
        clearInterval(interval);
        if (!cancelled && typeof onComplete === "function") {
          onComplete();
        }
        return;
      }

      const action = historyActions[currentIndex];
      currentIndex++;

      if (typeof onStep === "function") {
        onStep(currentIndex / totalSteps);
      }

      if (action.type === "stroke" && action.points && action.points.length > 0) {
        tCtx.strokeStyle = action.color || "#18181B";
        tCtx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
        tCtx.beginPath();
        tCtx.moveTo(action.points[0].x * scaleX, action.points[0].y * scaleY);
        for (let i = 1; i < action.points.length; i++) {
          const prev = action.points[i - 1];
          const curr = action.points[i];
          const midX = ((prev.x + curr.x) / 2) * scaleX;
          const midY = ((prev.y + curr.y) / 2) * scaleY;
          if (i === 1) {
            tCtx.lineTo(midX, midY);
          } else {
            tCtx.quadraticCurveTo(prev.x * scaleX, prev.y * scaleY, midX, midY);
          }
        }
        const last = action.points[action.points.length - 1];
        tCtx.lineTo(last.x * scaleX, last.y * scaleY);
        tCtx.stroke();
      } else if (action.type === "shape") {
        tCtx.strokeStyle = action.color || "#18181B";
        tCtx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
        const x1 = action.x1 * scaleX;
        const y1 = action.y1 * scaleY;
        const x2 = action.x2 * scaleX;
        const y2 = action.y2 * scaleY;
        if (action.shape === "rect") {
          tCtx.beginPath();
          tCtx.strokeRect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
        } else if (action.shape === "circle") {
          const cx = (x1 + x2) / 2;
          const cy = (y1 + y2) / 2;
          const rx = Math.max(1, Math.abs(x2 - x1) / 2);
          const ry = Math.max(1, Math.abs(y2 - y1) / 2);
          tCtx.beginPath();
          tCtx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
          tCtx.stroke();
        } else if (action.shape === "line") {
          tCtx.beginPath();
          tCtx.moveTo(x1, y1);
          tCtx.lineTo(x2, y2);
          tCtx.stroke();
        }
      } else if (action.type === "fill") {
        tCtx.fillStyle = action.color || "#18181B";
        tCtx.fillRect(0, 0, width, height);
      } else if (action.type === "clear") {
        tCtx.fillStyle = "#ffffff";
        tCtx.fillRect(0, 0, width, height);
      }
    }, stepInterval);

    return {
      cancel: () => {
        cancelled = true;
        clearInterval(interval);
      }
    };
  }

  // Renderização estática instantânea de histórico de desenho em qualquer canvas
  static renderStatic(targetCanvas, historyActions) {
    if (!targetCanvas) return;
    const tCtx = targetCanvas.getContext("2d");
    const width = targetCanvas.width;
    const height = targetCanvas.height;
    const scaleX = width / 1200;
    const scaleY = height / 720;

    tCtx.fillStyle = "#ffffff";
    tCtx.fillRect(0, 0, width, height);
    tCtx.lineCap = "round";
    tCtx.lineJoin = "round";

    if (!Array.isArray(historyActions) || historyActions.length === 0) return;

    for (const action of historyActions) {
      if (action.type === "stroke" && action.points && action.points.length > 0) {
        tCtx.strokeStyle = action.color || "#18181B";
        tCtx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
        tCtx.beginPath();
        tCtx.moveTo(action.points[0].x * scaleX, action.points[0].y * scaleY);
        for (let i = 1; i < action.points.length; i++) {
          const prev = action.points[i - 1];
          const curr = action.points[i];
          const midX = ((prev.x + curr.x) / 2) * scaleX;
          const midY = ((prev.y + curr.y) / 2) * scaleY;
          if (i === 1) {
            tCtx.lineTo(midX, midY);
          } else {
            tCtx.quadraticCurveTo(prev.x * scaleX, prev.y * scaleY, midX, midY);
          }
        }
        const last = action.points[action.points.length - 1];
        tCtx.lineTo(last.x * scaleX, last.y * scaleY);
        tCtx.stroke();
      } else if (action.type === "shape") {
        tCtx.strokeStyle = action.color || "#18181B";
        tCtx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
        const x1 = action.x1 * scaleX;
        const y1 = action.y1 * scaleY;
        const x2 = action.x2 * scaleX;
        const y2 = action.y2 * scaleY;
        if (action.shape === "rect") {
          tCtx.beginPath();
          tCtx.strokeRect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
        } else if (action.shape === "circle") {
          const cx = (x1 + x2) / 2;
          const cy = (y1 + y2) / 2;
          const rx = Math.max(1, Math.abs(x2 - x1) / 2);
          const ry = Math.max(1, Math.abs(y2 - y1) / 2);
          tCtx.beginPath();
          tCtx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
          tCtx.stroke();
        } else if (action.shape === "line") {
          tCtx.beginPath();
          tCtx.moveTo(x1, y1);
          tCtx.lineTo(x2, y2);
          tCtx.stroke();
        } else if (action.type === "fill") {
          tCtx.fillStyle = action.color || "#18181B";
          tCtx.fillRect(0, 0, width, height);
        } else if (action.type === "clear") {
          tCtx.fillStyle = "#ffffff";
          tCtx.fillRect(0, 0, width, height);
        }
      }
    }
  }

  // Exportação HD de Arte com Moldura Oficial Drawhio (v1.6)
  static exportFramedDrawing(historyActions, options = {}) {
    const totalW = options.width || 1400;
    const totalH = options.height || 920;
    const canvas = document.createElement("canvas");
    canvas.width = totalW;
    canvas.height = totalH;
    const ctx = canvas.getContext("2d");

    // 1. Fundo Gradiente Premium Drawhio
    const bgGrad = ctx.createLinearGradient(0, 0, totalW, totalH);
    bgGrad.addColorStop(0, "#0F172A");
    bgGrad.addColorStop(0.5, "#1E1B4B");
    bgGrad.addColorStop(1, "#311042");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, totalW, totalH);

    // Círculos de luz decorativos de fundo
    ctx.fillStyle = "rgba(139, 92, 246, 0.15)";
    ctx.beginPath();
    ctx.arc(120, 100, 260, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(236, 72, 153, 0.12)";
    ctx.beginPath();
    ctx.arc(totalW - 140, totalH - 100, 300, 0, Math.PI * 2);
    ctx.fill();

    // 2. Cabeçalho Superior Estilizado
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 26px sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText("DRAWHIO", 60, 55);

    ctx.fillStyle = "#A78BFA";
    ctx.font = "600 16px sans-serif";
    ctx.fillText("• Galeria Oficial de Arte", 195, 56);

    const dateStr = options.date || new Date().toLocaleDateString("pt-BR");
    ctx.fillStyle = "#94A3B8";
    ctx.textAlign = "right";
    ctx.font = "500 15px sans-serif";
    ctx.fillText(dateStr, totalW - 60, 56);

    // 3. Moldura Interna de Arte (Branca com Sombra Suave)
    const cardX = 60;
    const cardY = 95;
    const cardW = totalW - 120;
    const cardH = totalH - 180;

    ctx.save();
    ctx.shadowColor = "rgba(0, 0, 0, 0.45)";
    ctx.shadowBlur = 32;
    ctx.shadowOffsetY = 12;

    ctx.fillStyle = "#FFFFFF";
    if (typeof ctx.roundRect === "function") {
      ctx.beginPath();
      ctx.roundRect(cardX, cardY, cardW, cardH, 20);
      ctx.fill();
    } else {
      ctx.fillRect(cardX, cardY, cardW, cardH);
    }
    ctx.restore();

    // 4. Renderizar a Arte do Desenho dentro da moldura
    ctx.save();
    if (typeof ctx.roundRect === "function") {
      ctx.beginPath();
      ctx.roundRect(cardX, cardY, cardW, cardH, 20);
      ctx.clip();
    }

    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(cardX, cardY, cardW, cardH);

    const scaleX = cardW / 1200;
    const scaleY = cardH / 720;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (Array.isArray(historyActions)) {
      for (const action of historyActions) {
        if (action.type === "stroke" && action.points && action.points.length > 0) {
          ctx.strokeStyle = action.color || "#18181B";
          ctx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
          ctx.beginPath();
          ctx.moveTo(cardX + action.points[0].x * scaleX, cardY + action.points[0].y * scaleY);
          for (let i = 1; i < action.points.length; i++) {
            const prev = action.points[i - 1];
            const curr = action.points[i];
            const midX = cardX + ((prev.x + curr.x) / 2) * scaleX;
            const midY = cardY + ((prev.y + curr.y) / 2) * scaleY;
            if (i === 1) {
              ctx.lineTo(midX, midY);
            } else {
              ctx.quadraticCurveTo(cardX + prev.x * scaleX, cardY + prev.y * scaleY, midX, midY);
            }
          }
          const last = action.points[action.points.length - 1];
          ctx.lineTo(cardX + last.x * scaleX, cardY + last.y * scaleY);
          ctx.stroke();
        } else if (action.type === "shape") {
          ctx.strokeStyle = action.color || "#18181B";
          ctx.lineWidth = Math.max(1, (action.size || 9) * scaleX);
          const x1 = cardX + action.x1 * scaleX;
          const y1 = cardY + action.y1 * scaleY;
          const x2 = cardX + action.x2 * scaleX;
          const y2 = cardY + action.y2 * scaleY;
          if (action.shape === "rect") {
            ctx.beginPath();
            ctx.strokeRect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
          } else if (action.shape === "circle") {
            const cx = (x1 + x2) / 2;
            const cy = (y1 + y2) / 2;
            const rx = Math.max(1, Math.abs(x2 - x1) / 2);
            const ry = Math.max(1, Math.abs(y2 - y1) / 2);
            ctx.beginPath();
            ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
            ctx.stroke();
          } else if (action.shape === "line") {
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
          }
        } else if (action.type === "fill") {
          ctx.fillStyle = action.color || "#18181B";
          ctx.fillRect(cardX, cardY, cardW, cardH);
        } else if (action.type === "clear") {
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(cardX, cardY, cardW, cardH);
        }
      }
    }
    ctx.restore();

    // 5. Rodapé da Imagem com Assinatura e Título
    const footerY = totalH - 45;
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 20px sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    const titleText = options.title ? `"${options.title.toUpperCase()}"` : "ARTE LIVRE";
    ctx.fillText(titleText, 60, footerY);

    ctx.textAlign = "right";
    ctx.font = "600 16px sans-serif";
    ctx.fillStyle = "#E2E8F0";
    const authorText = `Artista: ${options.author || "Anônimo"}`;
    ctx.fillText(authorText, totalW - 60, footerY);

    return {
      canvas,
      toDataURL: () => canvas.toDataURL("image/png"),
      download: (filename = "drawhio_arte_hd.png") => {
        const a = document.createElement("a");
        a.download = filename;
        a.href = canvas.toDataURL("image/png");
        a.click();
      },
      copyToClipboard: async () => {
        return new Promise((resolve, reject) => {
          canvas.toBlob(async (blob) => {
            if (!blob) return reject(new Error("Erro ao gerar imagem."));
            try {
              if (navigator.clipboard && navigator.clipboard.write) {
                await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
                resolve(true);
              } else {
                reject(new Error("Área de transferência não suportada neste navegador."));
              }
            } catch (err) {
              reject(err);
            }
          }, "image/png");
        });
      }
    };
  }
}

window.DrawingBoard = DrawingBoard;

// =========================================================
// DRAWHIO - GERENCIADOR DE AVATAR & IDENTIFICAÇÃO DE GÊNERO
// =========================================================

const GENDER_AVATARS = {
  homem: {
    id: "homem",
    label: "Homem",
    icon: "icon_m.png",
    name: "Homem"
  },
  mulher: {
    id: "mulher",
    label: "Mulher",
    icon: "icon_f.png",
    name: "Mulher"
  },
  nb: {
    id: "nb",
    label: "Prefiro não me identificar",
    icon: "icon_nb.png",
    name: "Prefiro não me identificar"
  }
};

/**
 * Retorna o caminho da imagem correspondente ao avatar do jogador
 * @param {Object|string} avatar 
 * @returns {string} caminho da imagem (ex: "icon_m.png")
 */
function getAvatarSrc(avatar) {
  if (!avatar) return "icon_nb.png";

  if (typeof avatar === "string") {
    if (avatar.includes("icon_m")) return "icon_m.png";
    if (avatar.includes("icon_f")) return "icon_f.png";
    if (avatar.includes("icon_nb")) return "icon_nb.png";
    if (avatar === "homem" || avatar === "m") return "icon_m.png";
    if (avatar === "mulher" || avatar === "f") return "icon_f.png";
    if (avatar === "nb") return "icon_nb.png";
    return avatar;
  }

  // Se for objeto { icon, gender }
  if (avatar.icon) {
    if (avatar.icon.includes("icon_m")) return "icon_m.png";
    if (avatar.icon.includes("icon_f")) return "icon_f.png";
    if (avatar.icon.includes("icon_nb")) return "icon_nb.png";
    return avatar.icon;
  }

  if (avatar.gender) {
    if (avatar.gender === "homem" || avatar.gender === "m") return "icon_m.png";
    if (avatar.gender === "mulher" || avatar.gender === "f") return "icon_f.png";
    if (avatar.gender === "nb") return "icon_nb.png";
  }

  return "icon_nb.png";
}

/**
 * Renderiza a tag <img> oficial do avatar do jogador para uso em qualquer componente
 * (waiting room, placar in-game, chat, pódio)
 * @param {Object|string} avatar
 * @param {number} size
 * @returns {string} HTML <img>
 */
function renderAvatarSvg(avatar, size = 40) {
  const src = getAvatarSrc(avatar);
  const alt = (avatar && avatar.gender && GENDER_AVATARS[avatar.gender]) 
    ? GENDER_AVATARS[avatar.gender].label 
    : "Avatar";

  return `<img src="${src}" class="player-avatar-img" width="${size}" height="${size}" alt="${alt}" draggable="false" loading="eager" />`;
}

// Compatibilidade global
window.GENDER_AVATARS = GENDER_AVATARS;
window.AVATAR_COLORS = ["#6366f1", "#ec4899", "#8b5cf6", "#10b981"];
window.getAvatarSrc = getAvatarSrc;
window.renderAvatarSvg = renderAvatarSvg;
window.renderPlayerAvatar = renderAvatarSvg;

// Sistema de Efeitos Sonoros com Web Audio API Nativa
class SoundSystem {
  constructor() {
    this.ctx = null;
    this.isMuted = localStorage.getItem("gartic_muted") === "true";
    this.volume = parseFloat(localStorage.getItem("drawhio_volume") || "0.8");
  }

  setVolume(val) {
    this.volume = Math.max(0, Math.min(1, val));
    localStorage.setItem("drawhio_volume", this.volume);
  }

  initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    localStorage.setItem("gartic_muted", this.isMuted);
    return this.isMuted;
  }

  playTone(freq, type = "sine", duration = 0.2, startGain = 0.15, endGain = 0.001) {
    if (this.isMuted || this.volume <= 0) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      const effectiveGain = startGain * this.volume;
      gainNode.gain.setValueAtTime(effectiveGain, this.ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(endGain, this.ctx.currentTime + duration);

      osc.connect(gainNode);
      gainNode.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      console.warn("Audio error:", e);
    }
  }

  // Acerto de palavra: acorde brilhante (C5 -> E5 -> G5 -> C6)
  playCorrect() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        this.playTone(freq, "triangle", 0.35, 0.2, 0.001);
      }, idx * 75);
    });
  }

  // Palpite quase certo: "Está perto!"
  playClose() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    this.playTone(440, "sine", 0.15, 0.12, 0.001);
    setTimeout(() => {
      this.playTone(554.37, "sine", 0.2, 0.12, 0.001);
    }, 100);
  }

  // Tic-tac de contagem regressiva (<10s)
  playTick() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    this.playTone(800, "sine", 0.05, 0.08, 0.001);
  }

  // Alerta urgente (<5s)
  playUrgent() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    this.playTone(950, "square", 0.08, 0.1, 0.001);
  }

  // Início de rodada / hora de desenhar
  playRoundStart() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const chords = [440, 554.37, 659.25];
    chords.forEach((freq) => {
      this.playTone(freq, "triangle", 0.4, 0.15, 0.001);
    });
  }

  // Vitória final da partida
  playWin() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const fanfare = [
      { f: 523.25, d: 0.15, delay: 0 },
      { f: 659.25, d: 0.15, delay: 150 },
      { f: 783.99, d: 0.15, delay: 300 },
      { f: 1046.5, d: 0.5, delay: 450 }
    ];

    fanfare.forEach(item => {
      setTimeout(() => {
        this.playTone(item.f, "sine", item.d, 0.25, 0.001);
      }, item.delay);
    });
  }

  // Clique de ferramenta
  playClick() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    this.playTone(1200, "sine", 0.03, 0.05, 0.001);
  }

  // Novo jogador entra na sala: sino suave ascendente (F5 -> A5)
  playJoin() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    this.playTone(698.46, "sine", 0.12, 0.12, 0.001);
    setTimeout(() => {
      this.playTone(880.00, "sine", 0.18, 0.15, 0.001);
    }, 100);
  }

  // Jogador sai da sala: tom sutil descendente
  playLeave() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    this.playTone(587.33, "sine", 0.12, 0.1, 0.001);
    setTimeout(() => {
      this.playTone(440.00, "sine", 0.15, 0.08, 0.001);
    }, 90);
  }

  // Copiar código ou link: clique duplo rápido e nítido
  playCopy() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    this.playTone(1600, "triangle", 0.04, 0.14, 0.001);
    setTimeout(() => {
      this.playTone(2000, "triangle", 0.05, 0.14, 0.001);
    }, 60);
  }
}

window.soundSystem = new SoundSystem();

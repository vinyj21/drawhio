// =========================================================
// DRAWHIO - CLIENT LOGIC & REALTIME ENGINE
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
  // Resolução Dinâmica do Servidor Backend para Suporte a Hospedagem HTML Estática
  function resolveServerUrl() {
    const customUrl = localStorage.getItem("drawhio_custom_server_url");
    if (customUrl && customUrl.trim()) return customUrl.trim();

    if (window.DRAWHIO_CONFIG && window.DRAWHIO_CONFIG.SERVER_URL && window.DRAWHIO_CONFIG.SERVER_URL.trim()) {
      return window.DRAWHIO_CONFIG.SERVER_URL.trim();
    }

    if (window.location.protocol === "file:") {
      return "http://localhost:3000";
    }

    return window.location.origin;
  }

  const targetServerUrl = resolveServerUrl();
  const isStaticHost = (window.location.protocol.startsWith("http") && (
    window.location.hostname.includes("ct.ws") ||
    window.location.hostname.includes("infinityfree") ||
    window.location.hostname.includes("epizy.com") ||
    window.location.hostname.includes("rf.gd") ||
    window.location.hostname.includes("github.io") ||
    window.location.hostname.includes("vercel.app") ||
    window.location.hostname.includes("netlify.app")
  ));

  const hasConfiguredBackend = !!(
    localStorage.getItem("drawhio_custom_server_url") ||
    (window.DRAWHIO_CONFIG && window.DRAWHIO_CONFIG.SERVER_URL && window.DRAWHIO_CONFIG.SERVER_URL.trim())
  );

  const isSameOrigin = (window.location.protocol.startsWith("http") && targetServerUrl === window.location.origin);
  
  let socket = null;
  if (typeof io !== "undefined" && (!isStaticHost || hasConfiguredBackend)) {
    socket = isSameOrigin 
      ? io() 
      : io(targetServerUrl, {
          transports: ["websocket", "polling"],
          timeout: 10000,
          extraHeaders: {
            "Bypass-Tunnel-Reminder": "true"
          }
        });
  } else {
    socket = { on: () => {}, emit: () => {}, connected: false };
  }

  // Interceptar socket.on para direcionar eventos do motor local
  const origSocketOn = (socket && socket.on) ? socket.on.bind(socket) : () => {};
  socket.on = function(event, handler) {
    if (window.localDispatcher) {
      window.localDispatcher.on(event, handler);
    }
    return origSocketOn(event, handler);
  };

  let isLocalRoomActive = false;

  // Estado Local do Jogador & Identificação de Gênero
  const savedGender = localStorage.getItem("drawhio_gender") || null;
  let initialIcon = "icon_nb";
  if (savedGender === "homem") initialIcon = "icon_m";
  else if (savedGender === "mulher") initialIcon = "icon_f";
  else if (savedGender === "nb") initialIcon = "icon_nb";

  const localPlayer = {
    name: localStorage.getItem("drawhio_name") || "Artista",
    gender: savedGender,
    avatar: {
      icon: initialIcon,
      gender: savedGender || "nb"
    }
  };

  let currentRoom = null;
  let myPlayerId = null;
  let isCurrentHost = false;
  let isCurrentDrawer = false;
  let drawingBoard = null;
  let confettiCannon = new ConfettiCannon("confetti-canvas");
  let lastDrawerId = null;
  let lastRound = null;
  let lastGameState = null;
  let lastRoundSummary = null;

  // Sessão Resiliente (v1.6)
  function safeSessionGet(key) {
    try {
      return (typeof sessionStorage !== "undefined") ? sessionStorage.getItem(key) : null;
    } catch (e) { return null; }
  }
  function safeSessionSet(key, val) {
    try {
      if (typeof sessionStorage !== "undefined") sessionStorage.setItem(key, val);
    } catch (e) {}
  }
  function safeSessionRemove(key) {
    try {
      if (typeof sessionStorage !== "undefined") sessionStorage.removeItem(key);
    } catch (e) {}
  }

  let sessionToken = safeSessionGet("drawhio_session_token");
  if (!sessionToken) {
    sessionToken = "st_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
    safeSessionSet("drawhio_session_token", sessionToken);
  }

  // Elementos de Moderação & Exportação (v1.6)
  const votekickBanner = document.getElementById("votekick-banner");
  const votekickTargetName = document.getElementById("votekick-target-name");
  const votekickVoteCount = document.getElementById("votekick-vote-count");
  const votekickRequiredCount = document.getElementById("votekick-required-count");
  const votekickTimer = document.getElementById("votekick-timer");
  const btnVotekickYes = document.getElementById("btn-votekick-yes");
  const btnVotekickNo = document.getElementById("btn-votekick-no");
  const btnExportPodiumHd = document.getElementById("btn-export-podium-hd");
  const btnCopyPodiumHd = document.getElementById("btn-copy-podium-hd");

  // Telas Principais
  const lobbyScreen = document.getElementById("lobby-screen");
  const waitingRoomScreen = document.getElementById("waiting-room-screen");
  const gameScreen = document.getElementById("game-screen");

  // Elementos do Lobby Inicial (Drawhio)
  const inputPlayerName = document.getElementById("player-name-input");
  const charCounter = document.getElementById("char-counter");
  const cardCreateRoom = document.getElementById("card-create-room");
  const cardJoinRoom = document.getElementById("card-join-room");
  const quickJoinForm = document.getElementById("quick-join-form");
  const inputRoomCode = document.getElementById("room-code-input");
  const lobbyErrorMsg = document.getElementById("lobby-error-msg");
  const btnOpenSettings = document.getElementById("btn-open-settings");

  // Elementos da Sala de Espera (Waiting Room)
  const waitingRoomCode = document.getElementById("waiting-room-code");
  const btnCopyCodeBadge = document.getElementById("btn-copy-code-badge");
  const btnCopyRoomLink = document.getElementById("btn-copy-room-link");
  const btnCopyRoomLinkBanner = document.getElementById("btn-copy-room-link-banner");
  const btnLeaveLobby = document.getElementById("btn-leave-lobby");
  const waitingPlayersGrid = document.getElementById("waiting-players-grid");
  const waitingPlayerCount = document.getElementById("waiting-player-count");
  const btnStartGameLobby = document.getElementById("btn-start-game-lobby");
  const waitingHostNotice = document.getElementById("waiting-host-notice");
  const selectDuration = document.getElementById("select-game-duration");
  const selectRounds = document.getElementById("select-game-rounds");
  const selectPointsGoal = document.getElementById("select-game-points-goal");
  const dropdownGameGoal = document.getElementById("dropdown-game-goal");
  const dropdownGameRounds = document.getElementById("dropdown-game-rounds");
  const iconSettingGoal = document.getElementById("icon-setting-goal");
  const iconSettingRounds = document.getElementById("icon-setting-rounds");
  const labelColGoalRounds = document.getElementById("label-col-goal-rounds");
  const selectCategory = document.getElementById("select-game-category");
  const selectGameMode = document.getElementById("select-game-mode");

  // Modal de Palavras Personalizadas (v1.3)
  const customWordsModal = document.getElementById("custom-words-modal");
  const customWordsTextarea = document.getElementById("custom-words-textarea");
  const customWordsCountLabel = document.getElementById("custom-words-count-label");
  const btnSaveCustomWords = document.getElementById("btn-save-custom-words");
  const btnCancelCustomWords = document.getElementById("btn-cancel-custom-words");
  let localCustomWords = [];

  // Navegador de Salas Públicas (Lobby Browser - v1.4)
  const publicRoomsList = document.getElementById("public-rooms-list");
  const btnRefreshRooms = document.getElementById("btn-refresh-rooms");
  const btnOpenPublicRooms = document.getElementById("btn-open-public-rooms");
  const publicRoomsModal = document.getElementById("public-rooms-modal");
  const btnClosePublicRoomsModal = document.getElementById("btn-close-public-rooms-modal");
  const publicRoomsCounterBadge = document.getElementById("public-rooms-counter-badge");

  // Painel de Configurações / Convidado (v1.4)
  const waitingRoomSettingsBar = document.getElementById("waiting-room-settings-bar");
  const waitingGuestPanel = document.getElementById("waiting-guest-panel");
  const guestSettingDuration = document.getElementById("guest-setting-duration");
  const guestSettingRounds = document.getElementById("guest-setting-rounds");
  const guestSettingCategory = document.getElementById("guest-setting-category");
  const guestSettingMode = document.getElementById("guest-setting-mode");

  // Modal Explicativo dos Modos de Jogo (?)
  const btnExplainModes = document.getElementById("btn-explain-modes");
  const gameModesModal = document.getElementById("game-modes-modal");
  const btnCloseModesModal = document.getElementById("btn-close-modes-modal");
  const btnConfirmModesModal = document.getElementById("btn-confirm-modes-modal");

  // Modal de Criação de Sala (Pública / Privada / Senha)
  const createRoomModal = document.getElementById("create-room-modal");
  const btnCloseCreateModal = document.getElementById("btn-close-create-modal");
  const btnCancelCreateModal = document.getElementById("btn-cancel-create-modal");
  const formCreateRoomPrivacy = document.getElementById("form-create-room-privacy");
  const privatePasswordFieldGroup = document.getElementById("private-password-field-group");
  const inputCreateRoomPassword = document.getElementById("create-room-password");

  // Modal de Senha para Entrar em Sala
  const roomPasswordModal = document.getElementById("room-password-modal");
  const formSubmitRoomPassword = document.getElementById("form-submit-room-password");
  const inputRoomPasswordPrompt = document.getElementById("input-room-password-prompt");
  const btnCancelPasswordPrompt = document.getElementById("btn-cancel-password-prompt");
  const btnClosePasswordModal = document.getElementById("btn-close-password-modal");
  const roomPasswordError = document.getElementById("room-password-error");
  let pendingPasswordRoomCode = null;

  // Título Dinâmico das Configurações na Sala de Espera (Host vs Convidado)
  const waitingSettingsTitle = document.getElementById("waiting-settings-title");
  const waitingSettingsSubtitle = document.getElementById("waiting-settings-subtitle");
  const btnCloseCustomWords = document.getElementById("btn-close-custom-words");

  // Elementos do Modo Telefone Sem Fio (Gartic Phone - v1.4.1)
  const telefonePromptScreen = document.getElementById("telefone-prompt-screen");
  const formTelefonePrompt = document.getElementById("form-telefone-prompt");
  const telefonePromptInput = document.getElementById("telefone-prompt-input");
  const telefonePromptCharCount = document.getElementById("telefone-prompt-char-count");
  const telefonePromptTimer = document.getElementById("telefone-prompt-timer");
  const telefonePromptWaitingStatus = document.getElementById("telefone-prompt-waiting-status");
  const btnSubmitTelefonePrompt = document.getElementById("btn-submit-telefone-prompt");

  const telefoneDrawMissionBar = document.getElementById("telefone-draw-mission-bar");
  const telefoneDrawMissionText = document.getElementById("telefone-draw-mission-text");
  const telefoneDrawTimer = document.getElementById("telefone-draw-timer");
  const btnSubmitTelefoneDraw = document.getElementById("btn-submit-telefone-draw");
  const standardCanvasStatusBar = document.getElementById("standard-canvas-status-bar");

  const telefoneDescribeScreen = document.getElementById("telefone-describe-screen");
  const telefoneDescribePreviewCanvas = document.getElementById("telefone-describe-preview-canvas");
  const formTelefoneDescribe = document.getElementById("form-telefone-describe");
  const telefoneDescribeInput = document.getElementById("telefone-describe-input");
  const telefoneDescribeCharCount = document.getElementById("telefone-describe-char-count");
  const telefoneDescribeTimer = document.getElementById("telefone-describe-timer");
  const telefoneDescribeWaitingStatus = document.getElementById("telefone-describe-waiting-status");
  const btnSubmitTelefoneDescribe = document.getElementById("btn-submit-telefone-describe");

  const telefoneAlbumScreen = document.getElementById("telefone-album-screen");
  const albumOwnerTitle = document.getElementById("album-owner-title");
  const albumProgressSubtitle = document.getElementById("album-progress-subtitle");
  const telefoneAlbumStage = document.getElementById("telefone-album-stage");
  const albumHostControls = document.getElementById("album-host-controls");
  const albumGuestNotice = document.getElementById("album-guest-notice");
  const btnAlbumPrevSlide = document.getElementById("btn-album-prev-slide");
  const btnAlbumNextSlide = document.getElementById("btn-album-next-slide");
  const labelAlbumNext = document.getElementById("label-album-next");
  const btnAlbumFinish = document.getElementById("btn-album-finish");

  // Galeria Final do Telefone Sem Fio (v1.5)
  const telefoneFinalGallery = document.getElementById("telefone-final-gallery");
  const recapBooksContainer = document.getElementById("recap-books-container");
  const recapHostActions = document.getElementById("recap-host-actions");
  const recapGuestNotice = document.getElementById("recap-guest-notice");
  const btnRecapPlayAgain = document.getElementById("btn-recap-play-again");
  const btnRecapBackLobby = document.getElementById("btn-recap-back-lobby");

  // Elementos da Tela de Jogo (Layout Drawhio)
  const headerPlayerCount = document.getElementById("header-player-count");
  const ingamePlayerCount = document.getElementById("ingame-player-count");
  const displayBottomCode = document.getElementById("display-bottom-code");
  const btnCopyCodeBottom = document.getElementById("btn-copy-code-bottom");
  const btnBottomInvite = document.getElementById("btn-bottom-invite");
  const btnOpenSettingsGame = document.getElementById("btn-open-settings-game");
  const btnRoomDropdown = document.getElementById("btn-room-dropdown");
  const displayRound = document.getElementById("display-round");
  const roundInstructionText = document.getElementById("round-instruction-text");
  const timerDisplay = document.getElementById("timer-display");
  const wordDisplay = document.getElementById("word-display");
  const btnSoundToggle = document.getElementById("btn-sound-toggle");
  const btnLeaveRoom = document.getElementById("btn-leave-room");
  const playersList = document.getElementById("players-list");

  // Canvas e Ferramentas
  const drawingCanvas = document.getElementById("drawing-canvas");
  const reactionsOverlay = document.getElementById("floating-reactions-overlay");
  const remoteDrawerCursor = document.getElementById("remote-drawer-cursor");
  const drawingToolbar = document.getElementById("drawing-toolbar");
  const toolBrush = document.getElementById("tool-brush");
  const toolEraser = document.getElementById("tool-eraser");
  const toolFill = document.getElementById("tool-fill");
  const toolPipette = document.getElementById("tool-pipette");
  const toolRect = document.getElementById("tool-rect");
  const toolCircle = document.getElementById("tool-circle");
  const toolLine = document.getElementById("tool-line");
  const toolUndo = document.getElementById("tool-undo");
  const toolRedo = document.getElementById("tool-redo");
  const paletteContainer = document.getElementById("palette-colors");
  const customColorInput = document.getElementById("custom-color-input");

  // Chat e Palpites
  const chatMessages = document.getElementById("chat-messages");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");
  const btnToggleReactionsChat = document.getElementById("btn-toggle-reactions-chat");
  const btnBottomReactions = document.getElementById("btn-bottom-reactions");
  const reactionsPopover = document.getElementById("reactions-popover");

  // Modais
  const wordModal = document.getElementById("word-select-modal");
  const wordChoicesContainer = document.getElementById("word-choices-container");
  const wordSelectProgress = document.getElementById("word-select-progress");
  const wordModalCornerTimer = document.getElementById("word-modal-corner-timer");
  const wordSelectTimerSec = document.getElementById("word-select-timer-sec");

  const roundEndModal = document.getElementById("round-end-modal");
  const roundWordReveal = document.getElementById("round-word-reveal");
  const roundHintReveal = document.getElementById("round-hint-reveal");
  const roundScoresList = document.getElementById("round-scores-list");
  const btnPlayTimelapse = document.getElementById("btn-play-timelapse");
  const timelapseContainer = document.getElementById("timelapse-container");
  const timelapseCanvas = document.getElementById("timelapse-canvas");
  const timelapseProgressFill = document.getElementById("timelapse-progress-fill");
  let latestRoundDrawHistory = [];
  let currentTimelapsePlayer = null;

  const gameOverModal = document.getElementById("game-over-modal");
  const podiumContainer = document.getElementById("podium-container");
  const btnPlayAgain = document.getElementById("btn-play-again");
  const btnViewTelephoneGallery = document.getElementById("btn-view-telephone-gallery");
  const telephoneGalleryModal = document.getElementById("telephone-gallery-modal");
  const btnCloseTelephoneModal = document.getElementById("btn-close-telephone-modal");
  const btnConfirmTelephoneModal = document.getElementById("btn-confirm-telephone-modal");
  const telephoneEvolutionContainer = document.getElementById("telephone-evolution-container");
  let lastTelephoneChain = [];

  // Modal e Seleção de Gênero / Foto de Perfil
  const genderWelcomeModal = document.getElementById("gender-welcome-modal");
  const modalGenderBtns = document.querySelectorAll(".modal-gender-btn");
  const btnConfirmGenderModal = document.getElementById("btn-confirm-gender-modal");

  const settingsModal = document.getElementById("settings-modal");
  const btnCloseSettingsModal = document.getElementById("btn-close-settings-modal");
  const settingSoundFx = document.getElementById("setting-sound-fx");
  const settingVolumeSlider = document.getElementById("setting-volume-slider");
  const settingVolLabel = document.getElementById("setting-vol-label");
  const settingDarkTheme = document.getElementById("setting-dark-theme");

  // Elementos de Configuração do Servidor Backend (Hospedagem HTML Estática)
  const settingServerUrl = document.getElementById("setting-server-url");
  const btnTestServerConn = document.getElementById("btn-test-server-conn");
  const btnSaveServerConn = document.getElementById("btn-save-server-conn");
  const serverStatusPill = document.getElementById("server-status-pill");
  const serverStatusText = document.getElementById("server-status-text");
  const htmlHostServerAlert = document.getElementById("html-host-server-alert");
  const btnAlertConfigureServer = document.getElementById("btn-alert-configure-server");
  const btnAlertSoloMode = document.getElementById("btn-alert-solo-mode");
  const btnAlertDismiss = document.getElementById("btn-alert-dismiss");
  const btnOpenSoloDraw = document.getElementById("btn-open-solo-draw");

  const toastContainer = document.getElementById("toast-container");

  // =========================================================
  // TOAST NOTIFICATIONS
  // =========================================================
  function showToast(message, duration = 3000) {
    const toast = document.createElement("div");
    toast.className = "toast-message";
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, duration + 300);
  }

  // =========================================================
  // 1. INICIALIZAÇÃO DE NICKNAME E IDENTIFICAÇÃO DE GÊNERO
  // =========================================================
  inputPlayerName.value = localPlayer.name;
  charCounter.textContent = `${localPlayer.name.length}/16`;

  inputPlayerName.addEventListener("input", (e) => {
    const val = e.target.value.trim().slice(0, 16);
    localPlayer.name = val || "Artista";
    charCounter.textContent = `${e.target.value.length}/16`;
    localStorage.setItem("drawhio_name", localPlayer.name);
  });

  // Função central para definir a foto/gênero do jogador
  function setPlayerGender(gender, shouldSave = true) {
    let icon = "icon_nb";
    if (gender === "homem") icon = "icon_m";
    else if (gender === "mulher") icon = "icon_f";
    else if (gender === "nb") icon = "icon_nb";

    localPlayer.gender = gender;
    localPlayer.avatar = {
      icon: icon,
      gender: gender
    };

    if (shouldSave) {
      localStorage.setItem("drawhio_gender", gender);
    }

    // Atualizar seleção visual nos botões do modal de entrada
    modalGenderBtns.forEach(btn => {
      const isSelected = btn.dataset.gender === gender;
      btn.classList.toggle("active", isSelected);
      btn.setAttribute("aria-checked", isSelected ? "true" : "false");
    });
  }

  // Pré-selecionar visualmente caso já haja preferência salva
  if (savedGender) {
    setPlayerGender(savedGender, false);
  } else {
    setPlayerGender("nb", false);
  }

  // EXIBIR SEMPRE A PERGUNTA AO ABRIR O JOGO (E AO DAR F5)
  setTimeout(() => {
    if (genderWelcomeModal) {
      genderWelcomeModal.classList.remove("hidden");
    }
  }, 100);

  // Cliques nos botões de identificação do modal: APENAS seleciona visualmente (NÃO fecha o modal)
  modalGenderBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const gender = btn.dataset.gender;
      setPlayerGender(gender, true);
      soundSystem.playClick();
    });
  });

  // O modal fecha EXCLUSIVAMENTE quando o usuário clica no botão "Confirmar e Jogar"
  if (btnConfirmGenderModal) {
    btnConfirmGenderModal.addEventListener("click", () => {
      if (!localPlayer.gender) {
        setPlayerGender("nb", true);
      }
      if (genderWelcomeModal) {
        genderWelcomeModal.classList.add("hidden");
      }
      soundSystem.playClick();
      const label = (window.GENDER_AVATARS && window.GENDER_AVATARS[localPlayer.gender]) 
        ? window.GENDER_AVATARS[localPlayer.gender].label 
        : localPlayer.gender;
      showToast(`Foto de perfil confirmada: ${label}`);
    });
  }

  // =========================================================
  // 2. CONFIGURAÇÕES & MODAL DE AJUSTES
  // =========================================================
  btnOpenSettings.addEventListener("click", () => {
    settingsModal.classList.remove("hidden");
    soundSystem.playClick();
  });

  btnCloseSettingsModal.addEventListener("click", () => {
    settingsModal.classList.add("hidden");
  });

  settingSoundFx.addEventListener("change", (e) => {
    if (!e.target.checked) {
      if (!soundSystem.isMuted) soundSystem.toggleMute();
    } else {
      if (soundSystem.isMuted) soundSystem.toggleMute();
    }
    updateSoundButtonIcon();
  });

  settingVolumeSlider.addEventListener("input", (e) => {
    const val = parseInt(e.target.value);
    settingVolLabel.textContent = `Volume: ${val}%`;
    soundSystem.setVolume(val / 100);
  });

  settingDarkTheme.addEventListener("change", (e) => {
    if (e.target.checked) {
      document.body.classList.add("dark-theme");
      localStorage.setItem("drawhio_theme", "dark");
    } else {
      document.body.classList.remove("dark-theme");
      localStorage.setItem("drawhio_theme", "light");
    }
  });

  // Restaurar tema salvo
  if (localStorage.getItem("drawhio_theme") === "dark") {
    settingDarkTheme.checked = true;
    document.body.classList.add("dark-theme");
  }

  // =========================================================
  // 3. NAVEGAÇÃO & CRIAÇÃO/ENTRADA DE SALA
  // =========================================================
  function getPlayerName() {
    return inputPlayerName.value.trim().slice(0, 16) || "Artista";
  }

  function showLobbyError(msg) {
    lobbyErrorMsg.textContent = msg;
    lobbyErrorMsg.classList.remove("hidden");
    setTimeout(() => {
      lobbyErrorMsg.classList.add("hidden");
    }, 4500);
  }

  function startLocalOfflineRoom() {
    isLocalRoomActive = true;
    const name = getPlayerName();
    const res = window.LocalGameRoom.createRoom(
      { name: name, avatar: localPlayer.avatar },
      {
        roundDuration: selectDuration ? (parseInt(selectDuration.value) || 70) : 70,
        totalRounds: selectRounds ? (parseInt(selectRounds.value) || 3) : 3,
        pointsGoal: selectPointsGoal ? (parseInt(selectPointsGoal.value) || 120) : 120,
        category: selectCategory ? (selectCategory.value || "todos") : "todos",
        gameMode: selectGameMode ? (selectGameMode.value || "classico") : "classico"
      }
    );

    currentRoom = res.roomCode;
    isCurrentHost = true;
    safeSessionSet("drawhio_last_room", currentRoom);
    showWaitingRoom();
    showToast("🤖 Sala Local iniciada! O Robô Pintor está pronto para jogar com você.");
  }

  // Card "Criar sala" -> Abre modal de configuração (Pública vs Privada)
  cardCreateRoom.addEventListener("click", () => {
    if (!localPlayer.gender) {
      if (genderWelcomeModal) genderWelcomeModal.classList.remove("hidden");
      showLobbyError("Por favor, confirme como você se identifica antes de jogar.");
      return;
    }

    // Se o backend online não estiver conectado:
    if (!socket || !socket.connected) {
      const serverOfflineModal = document.getElementById("server-offline-modal");
      if (serverOfflineModal) {
        serverOfflineModal.classList.remove("hidden");
        return;
      }
    }

    if (createRoomModal) {
      createRoomModal.classList.remove("hidden");
    }
    soundSystem.playClick();
  });

  // Alternar opções de privacidade no modal de criação
  if (formCreateRoomPrivacy) {
    const privacyRadios = formCreateRoomPrivacy.querySelectorAll('input[name="room-privacy-type"]');
    privacyRadios.forEach(radio => {
      radio.addEventListener("change", (e) => {
        const val = e.target.value;
        document.querySelectorAll(".privacy-option-card").forEach(c => {
          c.classList.toggle("active", c.dataset.privacy === val);
        });
        if (privatePasswordFieldGroup) {
          if (val === "private") {
            privatePasswordFieldGroup.classList.remove("hidden");
          } else {
            privatePasswordFieldGroup.classList.add("hidden");
          }
        }
      });
    });

    formCreateRoomPrivacy.addEventListener("submit", (e) => {
      e.preventDefault();
      const privacyType = formCreateRoomPrivacy.elements["room-privacy-type"] ? formCreateRoomPrivacy.elements["room-privacy-type"].value : "public";
      const isPublic = privacyType === "public";
      const isLocal = (privacyType === "local") || (!socket || !socket.connected);
      const password = isPublic ? null : (inputCreateRoomPassword ? inputCreateRoomPassword.value.trim() || null : null);
      if (createRoomModal) createRoomModal.classList.add("hidden");

      const name = getPlayerName();
      soundSystem.playClick();

      if (isLocal) {
        startLocalOfflineRoom();
        return;
      }

      socket.emit("create_room", {
        playerName: name,
        sessionToken: sessionToken,
        avatar: localPlayer.avatar,
        roundDuration: selectDuration.value || 70,
        totalRounds: selectRounds ? selectRounds.value || 3 : 3,
        pointsGoal: selectPointsGoal ? selectPointsGoal.value || 120 : 120,
        category: selectCategory.value || "todos",
        gameMode: selectGameMode ? selectGameMode.value : "classico",
        customWords: (selectCategory.value === "personalizado") ? localCustomWords : [],
        isPublic: isPublic,
        password: password
      }, (res) => {
        if (res.success) {
          currentRoom = res.roomCode;
          safeSessionSet("drawhio_last_room", currentRoom);
          isCurrentHost = true;
          showWaitingRoom();
        } else {
          showLobbyError(res.reason || "Erro ao criar sala.");
        }
      });
    });
  }

  if (btnCloseCreateModal) {
    btnCloseCreateModal.addEventListener("click", () => {
      if (createRoomModal) createRoomModal.classList.add("hidden");
      soundSystem.playClick();
    });
  }
  if (btnCancelCreateModal) {
    btnCancelCreateModal.addEventListener("click", () => {
      if (createRoomModal) createRoomModal.classList.add("hidden");
      soundSystem.playClick();
    });
  }

  // Modal de Servidor Desconectado (Botões de Escolha)
  const btnChoiceOfflineRoom = document.getElementById("btn-choice-offline-room");
  const btnChoiceOnlineConfig = document.getElementById("btn-choice-online-config");
  const btnCloseOfflineModal = document.getElementById("btn-close-offline-modal");
  const serverOfflineModal = document.getElementById("server-offline-modal");

  if (btnChoiceOfflineRoom) {
    btnChoiceOfflineRoom.addEventListener("click", () => {
      if (serverOfflineModal) serverOfflineModal.classList.add("hidden");
      startLocalOfflineRoom();
    });
  }

  if (btnChoiceOnlineConfig) {
    btnChoiceOnlineConfig.addEventListener("click", () => {
      if (serverOfflineModal) serverOfflineModal.classList.add("hidden");
      if (settingsModal) settingsModal.classList.remove("hidden");
      if (settingServerUrl) settingServerUrl.focus();
    });
  }

  if (btnCloseOfflineModal) {
    btnCloseOfflineModal.addEventListener("click", () => {
      if (serverOfflineModal) serverOfflineModal.classList.add("hidden");
    });
  }

  // Função centralizada para entrar em uma sala (com suporte a senha)
  function joinRoom(code, password = "") {
    if (!localPlayer.gender) {
      if (genderWelcomeModal) genderWelcomeModal.classList.remove("hidden");
      showLobbyError("Por favor, confirme como você se identifica antes de jogar.");
      return;
    }

    if (code.toUpperCase().includes("ROBO") || code.toUpperCase().includes("LOCAL")) {
      startLocalOfflineRoom();
      return;
    }

    if (!socket || !socket.connected) {
      if (serverOfflineModal) {
        serverOfflineModal.classList.remove("hidden");
        return;
      }
    }

    const name = getPlayerName();
    soundSystem.playClick();

    socket.emit("join_room", {
      roomCode: code,
      sessionToken: sessionToken,
      playerName: name,
      avatar: localPlayer.avatar,
      password: password
    }, (res) => {
      if (res.success) {
        currentRoom = res.roomCode;
        safeSessionSet("drawhio_last_room", currentRoom);
        if (roomPasswordModal) roomPasswordModal.classList.add("hidden");
        showWaitingRoom();
      } else {
        if (res.requiresPassword) {
          pendingPasswordRoomCode = code;
          if (roomPasswordModal) {
            roomPasswordModal.classList.remove("hidden");
            if (roomPasswordError) roomPasswordError.classList.add("hidden");
            if (inputRoomPasswordPrompt) {
              inputRoomPasswordPrompt.value = "";
              inputRoomPasswordPrompt.focus();
            }
          }
        } else {
          if (roomPasswordModal && !roomPasswordModal.classList.contains("hidden")) {
            if (roomPasswordError) {
              roomPasswordError.textContent = res.reason || "Senha incorreta.";
              roomPasswordError.classList.remove("hidden");
            }
          } else {
            showLobbyError(res.reason || "Sala não encontrada ou cheia.");
          }
        }
      }
    });
  }

  // Submissão da senha caso a sala seja protegida
  if (formSubmitRoomPassword) {
    formSubmitRoomPassword.addEventListener("submit", (e) => {
      e.preventDefault();
      const pwd = inputRoomPasswordPrompt ? inputRoomPasswordPrompt.value.trim() : "";
      if (!pendingPasswordRoomCode) return;
      joinRoom(pendingPasswordRoomCode, pwd);
    });
  }

  function closePasswordPromptModal() {
    if (roomPasswordModal) roomPasswordModal.classList.add("hidden");
    pendingPasswordRoomCode = null;
    soundSystem.playClick();
  }

  if (btnCancelPasswordPrompt) btnCancelPasswordPrompt.addEventListener("click", closePasswordPromptModal);
  if (btnClosePasswordModal) btnClosePasswordModal.addEventListener("click", closePasswordPromptModal);

  // Card "Entrar em uma sala"
  cardJoinRoom.addEventListener("click", () => {
    inputRoomCode.focus();
    inputRoomCode.scrollIntoView({ behavior: "smooth", block: "center" });
    inputRoomCode.parentElement.style.boxShadow = "0 0 0 4px rgba(91, 69, 224, 0.3)";
    setTimeout(() => {
      inputRoomCode.parentElement.style.boxShadow = "";
    }, 1500);
    soundSystem.playClick();
  });

  // Form Código Rápido
  quickJoinForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const code = inputRoomCode.value.trim().toUpperCase();
    if (!code) {
      showLobbyError("Por favor, digite o código da sala.");
      inputRoomCode.focus();
      return;
    }
    joinRoom(code);
  });

  // =========================================================
  // LOBBY BROWSER: RENDERIZAÇÃO DE SALAS PÚBLICAS
  // =========================================================
  function renderPublicRooms(roomsList) {
    if (!publicRoomsList) return;
    if (publicRoomsCounterBadge) {
      const count = Array.isArray(roomsList) ? roomsList.length : 0;
      publicRoomsCounterBadge.textContent = `${count} ${count === 1 ? 'sala' : 'salas'}`;
    }

    if (!roomsList || roomsList.length === 0) {
      publicRoomsList.innerHTML = `
        <div class="public-rooms-empty-state">
          <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="#CBD5E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M8 12h8"></path>
          </svg>
          <strong>Nenhuma sala pública aberta no momento.</strong>
          <small>Que tal criar uma sala pública e esperar os amigos?</small>
        </div>
      `;
      return;
    }

    const modeLabels = {
      classico: "Clássico",
      rapido: "Rápido",
      duelo: "Duelo (1v1)",
      duelo_rush: "Duelo 1v1 Rush",
      telefone: "Telefone Sem Fio"
    };

    roomsList.forEach(r => {
      const card = document.createElement("div");
      card.className = "public-room-item-card";

      const modeLabel = modeLabels[r.gameMode] || "Clássico";
      const isFull = r.playerCount >= r.maxPlayers;
      const isPlaying = r.state !== "LOBBY";

      card.innerHTML = `
        <div class="room-card-top-row">
          <div class="room-card-host-info">
            <span class="room-card-host-name">Sala de ${escapeHtml(r.hostName)}</span>
          </div>
          <span class="room-card-code-badge">#${r.roomCode}</span>
        </div>

        <div class="room-card-badges-row">
          <span class="room-meta-pill pill-mode">${modeLabel}</span>
          <span class="room-meta-pill pill-theme">${escapeHtml(r.category)}</span>
          ${r.hasPassword ? '<span class="room-meta-pill pill-lock">Senha Protegida</span>' : ""}
        </div>

        <div class="room-card-bottom-row">
          <span class="room-card-players-count">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
            <span>${r.playerCount}/${r.maxPlayers}</span>
          </span>
          <button type="button" class="btn-join-public-room" ${isFull ? "disabled" : ""}>
            <span>${isFull ? "Lotada" : (isPlaying ? "Em Jogo" : "Entrar")}</span>
          </button>
        </div>
      `;

      const btnJoin = card.querySelector(".btn-join-public-room");
      if (btnJoin && !isFull) {
        btnJoin.addEventListener("click", () => {
          if (publicRoomsModal) publicRoomsModal.classList.add("hidden");
          if (r.hasPassword) {
            pendingPasswordRoomCode = r.roomCode;
            if (roomPasswordModal) {
              roomPasswordModal.classList.remove("hidden");
              if (roomPasswordError) roomPasswordError.classList.add("hidden");
              if (inputRoomPasswordPrompt) {
                inputRoomPasswordPrompt.value = "";
                inputRoomPasswordPrompt.focus();
              }
            }
          } else {
            joinRoom(r.roomCode);
          }
        });
      }

      publicRoomsList.appendChild(card);
    });
  }

  // Atualização em tempo real das salas públicas
  socket.on("public_rooms_updated", (list) => {
    renderPublicRooms(list);
  });

  if (btnRefreshRooms) {
    btnRefreshRooms.addEventListener("click", () => {
      socket.emit("get_public_rooms", renderPublicRooms);
      soundSystem.playClick();
    });
  }

  // Abertura do Modal de Salas Públicas (v1.4)
  if (btnOpenPublicRooms) {
    btnOpenPublicRooms.addEventListener("click", () => {
      if (publicRoomsModal) publicRoomsModal.classList.remove("hidden");
      socket.emit("get_public_rooms", renderPublicRooms);
      soundSystem.playClick();
    });
  }

  if (btnClosePublicRoomsModal) {
    btnClosePublicRoomsModal.addEventListener("click", () => {
      if (publicRoomsModal) publicRoomsModal.classList.add("hidden");
      soundSystem.playClick();
    });
  }

  // Buscar salas logo ao inicializar
  socket.emit("get_public_rooms", renderPublicRooms);

  // Modal Explicativo dos Modos de Jogo (?)
  if (btnExplainModes) {
    btnExplainModes.addEventListener("click", () => {
      if (gameModesModal) gameModesModal.classList.remove("hidden");
      soundSystem.playClick();
    });
  }
  if (btnCloseModesModal) btnCloseModesModal.addEventListener("click", () => gameModesModal.classList.add("hidden"));
  if (btnConfirmModesModal) btnConfirmModesModal.addEventListener("click", () => gameModesModal.classList.add("hidden"));

  // Auto-preencher caso venha via URL ?room=CODE
  const urlParams = new URLSearchParams(window.location.search);
  const roomParam = urlParams.get("room");
  if (roomParam) {
    inputRoomCode.value = roomParam.trim().toUpperCase();
    showToast(`Código ${roomParam.toUpperCase()} detectado! Clique em Entrar.`);
  }

  // =========================================================
  // 4. SALA DE ESPERA (WAITING ROOM LOBBY)
  // =========================================================
  function showWaitingRoom() {
    document.body.classList.remove("in-game-bg");
    document.body.classList.remove("telefone-mode-active");
    lobbyScreen.classList.add("hidden");
    gameScreen.classList.add("hidden");
    if (telefonePromptScreen) telefonePromptScreen.classList.add("hidden");
    if (telefoneDescribeScreen) telefoneDescribeScreen.classList.add("hidden");
    if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");
    if (telefoneDrawMissionBar) telefoneDrawMissionBar.classList.add("hidden");
    if (standardCanvasStatusBar) standardCanvasStatusBar.classList.remove("hidden");
    waitingRoomScreen.classList.remove("hidden");
    waitingRoomCode.textContent = currentRoom;
  }

  // Copiar apenas o código da sala (ex: ABCD12)
  function copyRoomCodeOnly() {
    if (!currentRoom) return;
    navigator.clipboard.writeText(currentRoom).then(() => {
      showToast(`Código copiado: ${currentRoom}!`);
      soundSystem.playCopy();
    }).catch(() => {
      showToast(`Código da sala: ${currentRoom}`);
    });
  }

  // Copiar o link completo de convite (ex: https://.../?room=ABCD12)
  function copyInviteLink() {
    if (!currentRoom) return;
    const inviteUrl = `${window.location.origin}/?room=${currentRoom}`;
    navigator.clipboard.writeText(inviteUrl).then(() => {
      showToast("Link de convite copiado para a área de transferência!");
      soundSystem.playCopy();
    }).catch(() => {
      showToast(`Compartilhe o código: ${currentRoom}`);
    });
  }

  if (btnCopyCodeBadge) btnCopyCodeBadge.addEventListener("click", copyRoomCodeOnly);
  if (btnCopyRoomLink) btnCopyRoomLink.addEventListener("click", copyInviteLink);
  if (btnCopyRoomLinkBanner) btnCopyRoomLinkBanner.addEventListener("click", copyInviteLink);
  if (btnCopyCodeBottom) btnCopyCodeBottom.addEventListener("click", copyInviteLink);
  if (btnBottomInvite) btnBottomInvite.addEventListener("click", copyInviteLink);
  if (btnRoomDropdown) btnRoomDropdown.addEventListener("click", copyInviteLink);

  if (btnOpenSettingsGame) {
    btnOpenSettingsGame.addEventListener("click", () => {
      settingsModal.classList.remove("hidden");
      soundSystem.playClick();
    });
  }

  btnLeaveLobby.addEventListener("click", () => {
    window.location.href = window.location.pathname;
  });

  btnLeaveRoom.addEventListener("click", () => {
    if (confirm("Deseja realmente sair da partida?")) {
      window.location.href = window.location.pathname;
    }
  });

  // Helper para analisar e separar palavras personalizadas
  function parseCustomWords(text) {
    if (!text) return [];
    return text
      .split(/[\n,;]+/)
      .map(w => w.trim())
      .filter(w => w.length >= 2 && !/^[0-9]+$/.test(w));
  }

  // Atualizar configurações pelo anfitrião
  function emitSettingsUpdate() {
    if (!isCurrentHost) return;
    socket.emit("update_settings", {
      roundDuration: selectDuration.value,
      totalRounds: selectRounds ? selectRounds.value : 3,
      pointsGoal: selectPointsGoal ? selectPointsGoal.value : 120,
      category: selectCategory.value,
      gameMode: selectGameMode ? selectGameMode.value : "classico",
      customWords: (selectCategory.value === "personalizado") ? localCustomWords : []
    });
  }

  // =========================================================
  // SISTEMA DE DROPDOWNS CUSTOMIZADOS (v1.4.1 - Menus Próprios e Sem Emojis)
  // =========================================================
  function initCustomDropdown(dropdownId, triggerId, menuId, labelId, hiddenInputId, onSelect) {
    const dropdownEl = document.getElementById(dropdownId);
    const triggerEl = document.getElementById(triggerId);
    const menuEl = document.getElementById(menuId);
    const labelEl = document.getElementById(labelId);
    const inputEl = document.getElementById(hiddenInputId);
    if (!dropdownEl || !triggerEl || !menuEl) return;

    triggerEl.addEventListener("click", (e) => {
      e.stopPropagation();
      if (!isCurrentHost) return;

      // Fechar outros dropdowns abertos
      document.querySelectorAll(".custom-dropdown").forEach(d => {
        if (d !== dropdownEl) {
          d.classList.remove("open");
          const m = d.querySelector(".custom-dropdown-menu");
          if (m) m.classList.add("hidden");
          const t = d.querySelector(".custom-dropdown-trigger");
          if (t) t.setAttribute("aria-expanded", "false");
        }
      });

      const isOpen = dropdownEl.classList.toggle("open");
      menuEl.classList.toggle("hidden", !isOpen);
      triggerEl.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    menuEl.querySelectorAll(".custom-dropdown-item").forEach(item => {
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        const value = item.getAttribute("data-value");
        const labelText = item.querySelector(".dropdown-item-label") 
          ? item.querySelector(".dropdown-item-label").textContent.trim() 
          : item.textContent.trim();

        dropdownEl.setAttribute("data-value", value);
        if (inputEl) inputEl.value = value;
        if (labelEl) labelEl.textContent = labelText;

        menuEl.querySelectorAll(".custom-dropdown-item").forEach(i => i.classList.remove("active"));
        item.classList.add("active");

        dropdownEl.classList.remove("open");
        menuEl.classList.add("hidden");
        triggerEl.setAttribute("aria-expanded", "false");

        if (typeof onSelect === "function") {
          onSelect(value, labelText);
        }
      });
    });
  }

  // Fechar menus de dropdown ao clicar fora
  document.addEventListener("click", () => {
    document.querySelectorAll(".custom-dropdown").forEach(d => {
      d.classList.remove("open");
      const m = d.querySelector(".custom-dropdown-menu");
      if (m) m.classList.add("hidden");
      const t = d.querySelector(".custom-dropdown-trigger");
      if (t) t.setAttribute("aria-expanded", "false");
    });
  });

  // Atualizar visualmente o dropdown a partir de valor externo (ex: room_state)
  function setCustomDropdownValue(dropdownId, triggerLabelId, hiddenInputId, value) {
    const dropdownEl = document.getElementById(dropdownId);
    const labelEl = document.getElementById(triggerLabelId);
    const inputEl = document.getElementById(hiddenInputId);
    if (!dropdownEl) return;

    dropdownEl.setAttribute("data-value", value);
    if (inputEl) inputEl.value = value;

    const targetItem = dropdownEl.querySelector(`.custom-dropdown-item[data-value="${value}"]`);
    if (targetItem) {
      dropdownEl.querySelectorAll(".custom-dropdown-item").forEach(i => i.classList.remove("active"));
      targetItem.classList.add("active");
      const labelText = targetItem.querySelector(".dropdown-item-label") 
        ? targetItem.querySelector(".dropdown-item-label").textContent.trim() 
        : targetItem.textContent.trim();
      if (labelEl) labelEl.textContent = labelText;
    }
  }

  function updateGoalOrRoundsVisibility(mode) {
    const isTelefone = (mode === "telefone");
    if (labelColGoalRounds) {
      labelColGoalRounds.textContent = isTelefone ? "Rodadas" : "Meta de pontos";
    }
    if (iconSettingGoal && iconSettingRounds) {
      if (isTelefone) {
        iconSettingGoal.classList.add("hidden");
        iconSettingRounds.classList.remove("hidden");
      } else {
        iconSettingGoal.classList.remove("hidden");
        iconSettingRounds.classList.add("hidden");
      }
    }
    if (dropdownGameGoal && dropdownGameRounds) {
      if (isTelefone) {
        dropdownGameGoal.classList.add("hidden");
        dropdownGameRounds.classList.remove("hidden");
      } else {
        dropdownGameGoal.classList.remove("hidden");
        dropdownGameRounds.classList.add("hidden");
      }
    }
  }

  // Inicializar os dropdowns de configurações do jogo
  initCustomDropdown("dropdown-game-duration", "trigger-duration", "menu-duration", "label-duration", "select-game-duration", () => {
    emitSettingsUpdate();
  });

  initCustomDropdown("dropdown-game-goal", "trigger-goal", "menu-goal", "label-goal", "select-game-points-goal", () => {
    emitSettingsUpdate();
  });

  initCustomDropdown("dropdown-game-rounds", "trigger-rounds", "menu-rounds", "label-rounds", "select-game-rounds", () => {
    emitSettingsUpdate();
  });

  initCustomDropdown("dropdown-game-category", "trigger-category", "menu-category", "label-category", "select-game-category", (val) => {
    if (val === "personalizado") {
      if (customWordsModal) {
        customWordsTextarea.value = localCustomWords.join(", ");
        updateCustomWordsCount();
        customWordsModal.classList.remove("hidden");
        customWordsTextarea.focus();
      }
    } else {
      emitSettingsUpdate();
    }
  });

  initCustomDropdown("dropdown-game-mode", "trigger-mode", "menu-mode", "label-mode", "select-game-mode", (mode) => {
    updateGoalOrRoundsVisibility(mode);
    emitSettingsUpdate();
  });

  function updateCustomWordsCount() {
    if (!customWordsCountLabel || !customWordsTextarea) return;
    const words = parseCustomWords(customWordsTextarea.value);
    const count = words.length;
    customWordsCountLabel.textContent = count === 1
      ? "1 palavra identificada"
      : `${count} palavras identificadas (mínimo recomendado: 5)`;
  }

  if (customWordsTextarea) {
    customWordsTextarea.addEventListener("input", updateCustomWordsCount);
  }

  if (btnSaveCustomWords) {
    btnSaveCustomWords.addEventListener("click", () => {
      const words = parseCustomWords(customWordsTextarea.value);
      if (words.length === 0) {
        showToast("Por favor, digite pelo menos 1 palavra personalizada!");
        return;
      }
      localCustomWords = words;
      if (customWordsModal) customWordsModal.classList.add("hidden");
      showToast(`${localCustomWords.length} palavras personalizadas salvas!`);
      soundSystem.playClick();
      emitSettingsUpdate();
    });
  }

  function closeCustomWordsModal() {
    if (customWordsModal) customWordsModal.classList.add("hidden");
    if (localCustomWords.length === 0) {
      selectCategory.value = "todos";
    }
    soundSystem.playClick();
    emitSettingsUpdate();
  }

  if (btnCancelCustomWords) btnCancelCustomWords.addEventListener("click", closeCustomWordsModal);
  if (btnCloseCustomWords) btnCloseCustomWords.addEventListener("click", closeCustomWordsModal);

  // Iniciar Jogo
  if (btnStartGameLobby) {
    btnStartGameLobby.addEventListener("click", () => {
      try {
        soundSystem.playClick();
      } catch (e) {}

      if (isLocalRoomActive && window.LocalGameRoom) {
        window.LocalGameRoom.settings = {
          roundDuration: selectDuration ? (parseInt(selectDuration.value) || 70) : 70,
          totalRounds: selectRounds ? (parseInt(selectRounds.value) || 3) : 3,
          pointsGoal: selectPointsGoal ? (parseInt(selectPointsGoal.value) || 120) : 120,
          category: selectCategory ? (selectCategory.value || "todos") : "todos",
          gameMode: selectGameMode ? (selectGameMode.value || "classico") : "classico"
        };
        window.LocalGameRoom.customWords = (selectCategory && selectCategory.value === "personalizado") ? localCustomWords : [];
        window.LocalGameRoom.startGame();
        return;
      }

      btnStartGameLobby.classList.add("btn-starting");
      const spanText = btnStartGameLobby.querySelector("span");
      const originalText = spanText ? spanText.textContent : "Começar jogo";
      if (spanText) spanText.textContent = "Iniciando...";

      socket.emit("start_game");

      setTimeout(() => {
        btnStartGameLobby.classList.remove("btn-starting");
        if (spanText) spanText.textContent = originalText;
      }, 2500);
    });
  }

  // =========================================================
  // 5. MOTOR DE DESENHO (CANVAS) & FERRAMENTAS
  // =========================================================
  drawingBoard = new DrawingBoard(drawingCanvas, {
    onActionEmit: (action) => {
      if (!isLocalRoomActive) {
        socket.emit("draw_action", action);
      }
    },
    onCursorEmit: (pos) => {
      if (!isLocalRoomActive) {
        socket.emit("drawer_cursor", pos);
      }
    }
  });

  // Paleta de Cores do Canvas com 10 tons ricos e balanceados
  const CANVAS_PALETTE = [
    "#18181B", "#FFFFFF", "#EF4444", "#F97316", "#FBBF24",
    "#22C55E", "#06B6D4", "#6366F1", "#A855F7", "#EC4899"
  ];

  const colorWheelPill = document.getElementById("btn-open-color-wheel");
  const customColorPreview = document.getElementById("custom-color-preview");

  function setActiveTool(tool) {
    [toolBrush, toolEraser, toolFill, toolPipette, toolRect, toolCircle, toolLine].forEach(b => b && b.classList.remove("active"));
    if (tool === "brush" && toolBrush) toolBrush.classList.add("active");
    if (tool === "eraser" && toolEraser) toolEraser.classList.add("active");
    if (tool === "fill" && toolFill) toolFill.classList.add("active");
    if (tool === "pipette" && toolPipette) toolPipette.classList.add("active");
    if (tool === "rect" && toolRect) toolRect.classList.add("active");
    if (tool === "circle" && toolCircle) toolCircle.classList.add("active");
    if (tool === "line" && toolLine) toolLine.classList.add("active");
  }

  // Renderizar bolinhas de cores da paleta
  if (paletteContainer) {
    paletteContainer.innerHTML = "";
    CANVAS_PALETTE.forEach((color, idx) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "palette-dot-item" + (idx === 0 ? " active" : "");
      btn.style.backgroundColor = color;
      btn.title = `Cor ${color}`;
      btn.addEventListener("click", () => {
        document.querySelectorAll(".palette-dot-item").forEach(b => b.classList.remove("active"));
        if (colorWheelPill) colorWheelPill.classList.remove("active");
        btn.classList.add("active");
        
        drawingBoard.setColor(color);
        if (customColorPreview) customColorPreview.style.backgroundColor = color;
        if (customColorInput && color.startsWith("#") && color.length === 7) {
          customColorInput.value = color;
        }
        
        // Se estava usando borracha, volta automaticamente para o pincel
        if (drawingBoard.currentTool === "eraser" || (toolEraser && toolEraser.classList.contains("active"))) {
          setActiveTool("brush");
          drawingBoard.setTool("brush");
        }
        soundSystem.playClick();
      });
      paletteContainer.appendChild(btn);
    });
  }

  // Clique na Roda de Cores -> abre seletor nativo sem bugs
  if (colorWheelPill && customColorInput) {
    colorWheelPill.addEventListener("click", (e) => {
      if (e.target !== customColorInput) {
        customColorInput.click();
      }
    });

    const handleCustomColor = (e) => {
      const chosenColor = e.target.value;
      drawingBoard.setColor(chosenColor);
      
      document.querySelectorAll(".palette-dot-item").forEach(b => b.classList.remove("active"));
      colorWheelPill.classList.add("active");
      if (customColorPreview) customColorPreview.style.backgroundColor = chosenColor;

      // Se estava na borracha, volta automaticamente para o pincel
      if (drawingBoard.currentTool === "eraser" || (toolEraser && toolEraser.classList.contains("active"))) {
        setActiveTool("brush");
        drawingBoard.setTool("brush");
      }
    };

    customColorInput.addEventListener("input", handleCustomColor);
    customColorInput.addEventListener("change", handleCustomColor);
  }

  // 4 Botões de Tamanho de Pincel
  document.querySelectorAll(".brush-dot-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".brush-dot-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const size = parseInt(btn.getAttribute("data-size")) || 9;
      drawingBoard.setSize(size);
      soundSystem.playClick();
    });
  });

  if (toolBrush) {
    toolBrush.addEventListener("click", () => {
      setActiveTool("brush");
      drawingBoard.setTool("brush");
      soundSystem.playClick();
    });
  }

  if (toolEraser) {
    toolEraser.addEventListener("click", () => {
      setActiveTool("eraser");
      drawingBoard.setTool("eraser");
      soundSystem.playClick();
    });
  }

  if (toolFill) {
    toolFill.addEventListener("click", () => {
      setActiveTool("fill");
      drawingBoard.setTool("fill");
      soundSystem.playClick();
    });
  }

  // Pipeta / Conta-gotas (v1.4)
  if (toolPipette) {
    toolPipette.addEventListener("click", () => {
      setActiveTool("pipette");
      drawingBoard.setTool("pipette");
      soundSystem.playClick();
      showToast("Pipeta ativa: clique em qualquer cor no desenho!");
    });
  }

  // Formas Geométricas Básicas (v1.4)
  if (toolRect) {
    toolRect.addEventListener("click", () => {
      setActiveTool("rect");
      drawingBoard.setTool("rect");
      soundSystem.playClick();
      showToast("Retângulo (segure Shift para Quadrado)");
    });
  }

  if (toolCircle) {
    toolCircle.addEventListener("click", () => {
      setActiveTool("circle");
      drawingBoard.setTool("circle");
      soundSystem.playClick();
      showToast("Círculo (segure Shift para Círculo Perfeito)");
    });
  }

  if (toolLine) {
    toolLine.addEventListener("click", () => {
      setActiveTool("line");
      drawingBoard.setTool("line");
      soundSystem.playClick();
      showToast("Linha Reta (segure Shift para 45° ou 90°)");
    });
  }

  // Captura de cor via Pipeta
  drawingBoard.onColorPicked = (pickedHex) => {
    setActiveTool("brush");
    drawingBoard.setTool("brush");
    document.querySelectorAll(".palette-dot-item").forEach(b => b.classList.remove("active"));
    if (colorWheelPill) colorWheelPill.classList.add("active");
    if (customColorPreview) customColorPreview.style.backgroundColor = pickedHex;
    if (customColorInput) customColorInput.value = pickedHex;
    soundSystem.playClick();
    showToast(`Cor capturada: ${pickedHex}!`);
  };

  if (toolUndo) {
    toolUndo.addEventListener("click", () => {
      drawingBoard.undo(true);
      soundSystem.playClick();
    });
  }

  if (toolRedo) {
    toolRedo.addEventListener("click", () => {
      drawingBoard.redo(true);
      soundSystem.playClick();
    });
  }

  const toolClear = document.getElementById("tool-clear");
  if (toolClear) {
    toolClear.addEventListener("click", () => {
      drawingBoard.clearCanvas(true);
      soundSystem.playClick();
      showToast("Tela limpa!");
    });
  }

  // =========================================================
  // 6. REAÇÕES FLUTUANTES (ÍCONES SVG PRÓPRIOS)
  // =========================================================
  const REACTION_SVGS = {
    heart: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#EF4444"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>`,
    fire: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#F97316"><path d="M12 23c-4.97 0-9-4.03-9-9 0-4.14 2.82-7.61 6.64-8.66.44-.12.87.16.96.6.09.4-.11.8-.48.97-1.38.65-2.12 2.12-2.12 3.59 0 2.21 1.79 4 4 4s4-1.79 4-4c0-.79-.23-1.54-.64-2.17-.23-.35-.16-.83.17-1.1.33-.27.81-.24 1.1.08C18.42 9.53 19.5 11.66 19.5 14c0 4.97-4.03 9-9 9-1.38 0-2.67-.31-3.83-.87C5.07 20.31 3.86 17.3 4 14c.26-6.19 5.29-11 11.5-11 .39 0 .74.27.83.66.09.39-.12.78-.5.91-2.9 1.01-4.83 3.75-4.83 6.93 0 1.1.9 2 2 2s2-.9 2-2c0-.52-.16-1.02-.45-1.44-.22-.32-.17-.76.13-1.02.3-.26.74-.24 1.01.05C17.07 10.61 18 12.21 18 14c0 3.31-2.69 6-6 6z"/></svg>`,
    idea: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#EAB308"><path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z"/></svg>`,
    star: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#FBBF24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    sparkle: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#8B5CF6"><path d="M12 3l1.8 4.8L18.6 9.6l-4.8 1.8L12 16.2l-1.8-4.8L5.4 9.6l4.8-1.8L12 3zm6.5 11l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9.9-2.4zM5.5 13l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9.9-2.4z"/></svg>`,
    thumbsup: `<svg viewBox="0 0 24 24" width="32" height="32" fill="#3B82F6"><path d="M2 20h2c.55 0 1-.45 1-1v-9c0-.55-.45-1-1-1H2v11zm19.83-7.12c.11-.25.17-.52.17-.8V11c0-1.1-.9-2-2-2h-5.5l.92-4.65c.05-.22.02-.46-.08-.66-.23-.45-.75-.69-1.24-.56L10.5 4.5 6.7 8.3c-.44.44-.7.86-.7 1.7v7c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.12-.47.12-.72 0-.05 0-.1-.01-.15z"/></svg>`
  };

  function toggleReactionsPopover() {
    if (reactionsPopover) {
      reactionsPopover.classList.toggle("hidden");
    }
  }

  if (btnBottomReactions) btnBottomReactions.addEventListener("click", toggleReactionsPopover);
  if (btnToggleReactionsChat) btnToggleReactionsChat.addEventListener("click", toggleReactionsPopover);

  document.querySelectorAll(".btn-popover-react, .btn-quick-react").forEach(btn => {
    btn.addEventListener("click", () => {
      const reaction = btn.getAttribute("data-reaction") || "heart";
      socket.emit("send_reaction", reaction);
      if (reactionsPopover) reactionsPopover.classList.add("hidden");
      soundSystem.playClick();
    });
  });

  function spawnFloatingReaction(reactionKey) {
    const svgContent = REACTION_SVGS[reactionKey] || REACTION_SVGS.heart;
    const el = document.createElement("div");
    el.className = "floating-reaction-svg";
    el.innerHTML = svgContent;

    const randomX = 15 + Math.random() * 70;
    el.style.left = `${randomX}%`;

    reactionsOverlay.appendChild(el);
    setTimeout(() => {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 2900);
  }

  // =========================================================
  // 7. CHAT & PALPITES (SISTEMA DRAWHIO 100% FUNCIONAL)
  // =========================================================
  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;

    if (isLocalRoomActive && window.LocalGameRoom) {
      window.LocalGameRoom.handlePlayerGuess(text);
    } else {
      socket.emit("send_chat", text);
    }
    chatInput.value = "";
    chatInput.focus();
  });

  function addChatMessage(type, text, sender = null, timestamp = null, points = null) {
    if (!text && type !== "correct-guess") return;
    const now = new Date();
    const timeStr = timestamp || `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const isMe = sender && (sender.id === socket.id);
    const senderName = sender ? sender.name : "Sistema";

    // 1. Mensagem de Sistema (ex: "Nina entrou na sala")
    if (type === "system") {
      const row = document.createElement("div");
      row.className = "chat-system-row";
      row.innerHTML = `
        <div class="system-text-group">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#6366F1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
          </svg>
          <span>${escapeHtml(text)}</span>
        </div>
        <span class="system-time">${timeStr}</span>
      `;
      chatMessages.appendChild(row);
      chatMessages.scrollTop = chatMessages.scrollHeight;
      return;
    }

    // 2. Mensagem de Jogador (Chute, Acerto, Quase lá)
    const row = document.createElement("div");
    row.className = "chat-row" + (isMe ? " is-me" : "");

    // Avatar do jogador
    const avatarSvg = (sender && sender.avatar) 
      ? renderAvatarSvg(sender.avatar, 28)
      : `<svg viewBox="0 0 24 24" width="28" height="28" fill="#6366F1"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>`;

    let bubbleHtml = "";
    if (type === "correct-guess" || type === "success") {
      bubbleHtml = `
        <div class="chat-bubble bubble-correct">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          <span>${escapeHtml(text || "acertei!")}</span>
        </div>
        <div class="chat-points-badge">+${points || 10} pontos</div>
      `;
      soundSystem.playCorrect();
    } else if (type === "close-guess") {
      bubbleHtml = `
        <div class="chat-bubble bubble-close">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2c1.1 0 2 .9 2 2 0 .74-.4 1.38-1 1.72v2.34c3.95.49 7 3.85 7 7.94 0 4.41-3.59 8-8 8s-8-3.59-8-8c0-4.09 3.05-7.45 7-7.94V5.72C8.4 5.38 8 4.74 8 4c0-1.1.9-2 2-2z"/></svg>
          <span>${escapeHtml(text)}</span>
        </div>
      `;
      soundSystem.playClose();
    } else {
      bubbleHtml = `
        <div class="chat-bubble">
          ${escapeHtml(text)}
        </div>
      `;
    }

    row.innerHTML = `
      <div class="chat-msg-avatar">${avatarSvg}</div>
      <div class="chat-msg-body">
        <div class="chat-msg-header">
          <span class="chat-msg-name">${escapeHtml(senderName)}${isMe ? " (Você)" : ""}</span>
          <span class="chat-msg-time">${timeStr}</span>
        </div>
        ${bubbleHtml}
      </div>
    `;

    chatMessages.appendChild(row);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // Alternador de Som no Jogo com Ícone SVG Próprio
  function updateSoundButtonIcon() {
    if (soundSystem.isMuted) {
      btnSoundToggle.innerHTML = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
          <line x1="23" y1="9" x2="17" y2="15"></line>
          <line x1="17" y1="9" x2="23" y2="15"></line>
        </svg>
      `;
      btnSoundToggle.title = "Som Desligado (Clique para Ligar)";
    } else {
      btnSoundToggle.innerHTML = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
          <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
          <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
        </svg>
      `;
      btnSoundToggle.title = "Som Ligado (Clique para Mutar)";
    }
  }
  btnSoundToggle.addEventListener("click", () => {
    soundSystem.toggleMute();
    updateSoundButtonIcon();
  });
  updateSoundButtonIcon();

  // =========================================================
  // 8. SINCRONIZAÇÃO DE EVENTOS SOCKET.IO
  // =========================================================

  socket.on("connect", () => {
    myPlayerId = socket.id;
  });

  // Notificações de erro da sala / lobby
  socket.on("lobby_error", (msg) => {
    showToast(msg || "Não foi possível iniciar a partida.");
    showLobbyError(msg || "Não foi possível iniciar a partida.");
    if (btnStartGameLobby) {
      btnStartGameLobby.classList.remove("btn-starting");
      const spanText = btnStartGameLobby.querySelector("span");
      if (spanText) spanText.textContent = "Começar jogo";
      btnStartGameLobby.classList.add("shake-error");
      setTimeout(() => btnStartGameLobby.classList.remove("shake-error"), 600);
    }
  });

  // Notificações sonoras e visuais de entrada e saída de jogadores
  socket.on("player_joined", (player) => {
    soundSystem.playJoin();
    if (player && player.id !== socket.id) {
      showToast(`${player.name} entrou na sala!`);
    }
  });

  socket.on("player_left", (player) => {
    soundSystem.playLeave();
    if (player) {
      showToast(`${player.name} saiu da sala.`);
    }
  });

  // Reações flutuantes recebidas da sala
  socket.on("floating_reaction", (data) => {
    spawnFloatingReaction(data.emoji);
  });

  // Cursor remoto do desenhista
  socket.on("remote_cursor", (pos) => {
    if (isCurrentDrawer) return;
    remoteDrawerCursor.classList.remove("hidden");
    const rect = drawingCanvas.getBoundingClientRect();
    remoteDrawerCursor.style.left = `${pos.x * rect.width}px`;
    remoteDrawerCursor.style.top = `${pos.y * rect.height}px`;
  });

  // Ações de desenho sincronizadas
  socket.on("draw_action", (action) => {
    // Se o desenhista atual for eu, a ação já foi aplicada localmente em tempo real; não duplicar!
    if (isCurrentDrawer && action.type !== "clear") {
      return;
    }
    drawingBoard.applyAction(action);
  });

  socket.on("clear_canvas", () => {
    drawingBoard.clearCanvas(false);
  });

  socket.on("sync_canvas_history", (history) => {
    drawingBoard.loadHistory(history);
  });

  // Mensagens do servidor (Chat e Palpites)
  socket.on("chat_message", (data) => {
    const text = data.message || data.content;
    addChatMessage(data.type, text, data.sender, data.timestamp, data.points);
  });

  socket.on("close_guess", (data) => {
    const text = (typeof data === "object" && data !== null && data.guess) ? data.guess : String(data || "");
    addChatMessage("close-guess", `"${text}" está quase lá! (Muito perto!)`, null);
  });

  // 9. Atualização em Tempo Real do Cronômetro
  socket.on("timer_update", (data) => {
    if (typeof data.timeRemaining === "number") {
      timerDisplay.textContent = `${data.timeRemaining}s`;

      timerDisplay.classList.remove("timer-warning", "timer-danger");
      if (data.timeRemaining <= 10 && data.timeRemaining > 5) {
        timerDisplay.classList.add("timer-warning");
        soundSystem.playTick();
      } else if (data.timeRemaining <= 5 && data.timeRemaining > 0) {
        timerDisplay.classList.add("timer-danger");
        soundSystem.playUrgent();
      }

      if (wordSelectProgress) {
        const pct = (data.timeRemaining / 15) * 100;
        wordSelectProgress.style.width = `${Math.max(0, Math.min(100, pct))}%`;
      }
      if (wordModalCornerTimer) {
        wordModalCornerTimer.textContent = `${data.timeRemaining}s`;
      }
      if (wordSelectTimerSec) {
        wordSelectTimerSec.textContent = `${data.timeRemaining}s`;
      }
    }

    // Atualizar dica de letras reveladas para os adivinhadores
    if (data.maskedHint && !isCurrentDrawer) {
      wordDisplay.textContent = data.maskedHint.toUpperCase().split("").join(" ");
    }
  });

  // Atualização Geral do Estado da Sala
  socket.on("room_state", (state) => {
    currentRoom = state.roomId;
    if (displayBottomCode) displayBottomCode.textContent = state.roomId;
    if (waitingRoomCode) waitingRoomCode.textContent = state.roomId;
    if (headerPlayerCount) headerPlayerCount.textContent = state.players.length;
    if (ingamePlayerCount) ingamePlayerCount.textContent = `(${state.players.length})`;

    const me = state.players.find(p => p.id === socket.id);
    isCurrentHost = Boolean(me && me.isHost);
    isCurrentDrawer = Boolean(state.isDrawer);

    // Ajustar visibilidade dos controles de Host vs Painel de Convidado (v1.4)
    if (isCurrentHost) {
      btnStartGameLobby.classList.remove("hidden");
      waitingHostNotice.classList.add("hidden");
      if (waitingRoomSettingsBar) waitingRoomSettingsBar.classList.remove("hidden");
      if (waitingGuestPanel) waitingGuestPanel.classList.add("hidden");
      if (waitingSettingsTitle) waitingSettingsTitle.textContent = "Configurações da partida";
      if (waitingSettingsSubtitle) waitingSettingsSubtitle.textContent = "Personalize como será o jogo!";
      selectDuration.removeAttribute("disabled");
      selectRounds.removeAttribute("disabled");
      selectCategory.removeAttribute("disabled");
      if (selectGameMode) selectGameMode.removeAttribute("disabled");
    } else {
      btnStartGameLobby.classList.add("hidden");
      waitingHostNotice.classList.remove("hidden");
      if (waitingRoomSettingsBar) waitingRoomSettingsBar.classList.add("hidden");
      if (waitingSettingsTitle) waitingSettingsTitle.textContent = "Regras da Partida";
      if (waitingSettingsSubtitle) waitingSettingsSubtitle.textContent = "Definidas pelo anfitrião da sala";
      if (waitingGuestPanel) {
        waitingGuestPanel.classList.remove("hidden");
        const isTelefone = (state.settings && state.settings.gameMode === "telefone");
        const guestRoundsTitle = document.getElementById("guest-setting-rounds-title");
        if (guestRoundsTitle) {
          guestRoundsTitle.textContent = isTelefone ? "Rodadas" : "Meta de Pontos";
        }
        if (guestSettingRounds) {
          guestSettingRounds.textContent = isTelefone
            ? (state.settingsSummary ? state.settingsSummary.roundsText : `${state.settings.totalRounds} rodadas`)
            : (state.settingsSummary && state.settingsSummary.goalText ? state.settingsSummary.goalText : `${state.settings.pointsGoal || 120} pts`);
        }
        if (state.settingsSummary) {
          if (guestSettingDuration) guestSettingDuration.textContent = state.settingsSummary.durationText;
          if (guestSettingCategory) guestSettingCategory.textContent = state.settingsSummary.categoryText;
          if (guestSettingMode) guestSettingMode.textContent = state.settingsSummary.modeText;
        } else if (state.settings) {
          if (guestSettingDuration) guestSettingDuration.textContent = `${state.settings.roundDuration}s`;
          if (guestSettingCategory) guestSettingCategory.textContent = state.settings.category;
          if (guestSettingMode) guestSettingMode.textContent = state.settings.gameMode;
        }
      }
      selectDuration.setAttribute("disabled", "true");
      if (selectPointsGoal) selectPointsGoal.setAttribute("disabled", "true");
      if (selectRounds) selectRounds.setAttribute("disabled", "true");
      selectCategory.setAttribute("disabled", "true");
      if (selectGameMode) selectGameMode.setAttribute("disabled", "true");
    }

    // Sincronizar campos de opções (incluindo Dropdowns Customizados)
    if (state.settings) {
      setCustomDropdownValue("dropdown-game-duration", "label-duration", "select-game-duration", state.settings.roundDuration);
      if (state.settings.pointsGoal) {
        setCustomDropdownValue("dropdown-game-goal", "label-goal", "select-game-points-goal", state.settings.pointsGoal);
      }
      setCustomDropdownValue("dropdown-game-rounds", "label-rounds", "select-game-rounds", state.settings.totalRounds);
      setCustomDropdownValue("dropdown-game-category", "label-category", "select-game-category", state.settings.category);
      if (state.settings.gameMode) {
        setCustomDropdownValue("dropdown-game-mode", "label-mode", "select-game-mode", state.settings.gameMode);
        updateGoalOrRoundsVisibility(state.settings.gameMode);
      }
      if (state.settings.customWords && Array.isArray(state.settings.customWords)) {
        localCustomWords = state.settings.customWords;
      }
    }

    // Transição de Telas
    if (state.state === "LOBBY") {
      showWaitingRoom();
      renderWaitingPlayers(state.players);
    } else if (state.state.startsWith("TELEFONE_")) {
      if (lobbyScreen) lobbyScreen.classList.add("hidden");
      if (waitingRoomScreen) waitingRoomScreen.classList.add("hidden");
      renderIngameLeaderboard(state.players, state.currentDrawerId);
    } else {
      lobbyScreen.classList.add("hidden");
      waitingRoomScreen.classList.add("hidden");
      if (telefonePromptScreen) telefonePromptScreen.classList.add("hidden");
      if (telefoneDescribeScreen) telefoneDescribeScreen.classList.add("hidden");
      if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");
      if (telefoneDrawMissionBar) telefoneDrawMissionBar.classList.add("hidden");
      if (standardCanvasStatusBar) standardCanvasStatusBar.classList.remove("hidden");
      gameScreen.classList.remove("hidden");
      document.body.classList.add("in-game-bg");
      renderIngameLeaderboard(state.players, state.currentDrawerId);
    }

    // Detecção de novo desenhista ou início de nova rodada para limpar o canvas
    const drawerChanged = (state.currentDrawerId !== lastDrawerId);
    const roundChanged = (state.currentRound !== lastRound);
    const stateChangedToSelect = (state.state === "SELECTING_WORD" && lastGameState !== "SELECTING_WORD");

    if (drawerChanged || roundChanged || stateChangedToSelect || state.state === "SELECTING_WORD") {
      if (drawingBoard) {
        drawingBoard.clearCanvas(false);
      }
    }

    lastDrawerId = state.currentDrawerId;
    lastRound = state.currentRound;
    lastGameState = state.state;

    // Informações da Rodada e Status Superior
    if (displayRound) {
      if (state.settings && state.settings.gameMode === "telefone") {
        displayRound.textContent = `Rodada ${state.currentRound}/${state.totalRounds}`;
      } else {
        const goalPts = state.settings ? (state.settings.pointsGoal || 120) : 120;
        displayRound.textContent = `Meta: ${goalPts} pts`;
      }
    }
    timerDisplay.textContent = `${state.timeRemaining}s`;

    if (roundInstructionText) {
      roundInstructionText.textContent = isCurrentDrawer
        ? "Desenhe para os outros adivinharem!"
        : "Adivinhe o que estão desenhando!";
    }

    // Palavra Secreta / Dica Mascarada
    if (isCurrentDrawer && state.secretWord) {
      wordDisplay.textContent = state.secretWord.toUpperCase().split("").join(" ");
      wordDisplay.style.color = "var(--text-headline)";
      drawingBoard.setInteractive(true);
      drawingToolbar.classList.remove("hidden");
      remoteDrawerCursor.classList.add("hidden");
      chatInput.removeAttribute("disabled");
      chatInput.placeholder = "Você está desenhando! Diga algo no chat...";
    } else {
      const hint = state.maskedHint || state.maskedWord || "_ _ _ _ _";
      wordDisplay.textContent = hint.toUpperCase().split("").join(" ");
      wordDisplay.style.color = "var(--text-headline)";
      drawingBoard.setInteractive(false);
      drawingToolbar.classList.add("hidden");
      chatInput.removeAttribute("disabled");
      chatInput.placeholder = (me && me.hasGuessed) ? "Você acertou! Converse com os outros." : "Digite seu palpite...";
    }

    // Controle de Modais Conforme o Estado
    if (state.state === "SELECTING_WORD" && isCurrentDrawer && state.wordChoices && state.wordChoices.length > 0) {
      showWordSelectModal(state.wordChoices);
    } else {
      hideWordSelectModal();
    }

    if (state.state === "ROUND_END" && state.roundSummary) {
      showRoundEndModal(state.roundSummary);
    } else {
      roundEndModal.classList.add("hidden");
    }

    if (state.state === "GAME_OVER" && state.podium) {
      showGameOverModal(state.podium);
    } else {
      gameOverModal.classList.add("hidden");
    }
  });

  // Renderizar Jogadores na Sala de Espera (8 Slots do Lobby v1.3 - Fiel ao Mockup)
  function renderWaitingPlayers(players) {
    if (waitingPlayerCount) waitingPlayerCount.textContent = players.length;
    if (!waitingPlayersGrid) return;
    waitingPlayersGrid.innerHTML = "";

    // Jogadores conectados (cards destacados com borda roxa)
    players.forEach(p => {
      const isMe = (p.id === socket.id);
      const card = document.createElement("div");
      card.className = "player-waiting-card" + (isMe ? " is-me" : "");

      const crownEl = p.isHost ? `
        <div class="slot-crown" title="Anfitrião">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="#F59E0B">
            <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/>
          </svg>
        </div>` : "";

      // Obter avatar: imagem de gênero (icon_m, icon_f, icon_nb) ou SVG procedural
      let avatarHtml = "";
      if (p.avatar && p.avatar.gender && window.GENDER_AVATARS && window.GENDER_AVATARS[p.avatar.gender]) {
        const iconFile = window.GENDER_AVATARS[p.avatar.gender].icon;
        avatarHtml = `<img src="${iconFile}" alt="${escapeHtml(p.name)}" class="player-avatar-img" style="width: 100%; height: 100%; object-fit: cover;">`;
      } else {
        avatarHtml = renderAvatarSvg(p.avatar, 50);
      }

      const youBadge = isMe ? `<span class="slot-you-badge">você</span>` : "";
      const botBadge = p.isBot ? `<span class="slot-bot-badge">bot</span>` : "";

      const kickBtn = (isCurrentHost && !isMe && !p.isBot) ? `
        <button type="button" class="player-kick-trigger-btn" data-kick-id="${p.id}" data-kick-name="${escapeHtml(p.name)}" title="Expulsar da Sala">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      ` : "";

      card.innerHTML = `
        ${crownEl}
        <div class="slot-avatar-img-wrap">${avatarHtml}</div>
        <div class="slot-player-name">
          <span title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</span>
          ${youBadge}
          ${botBadge}
        </div>
        ${kickBtn}
      `;
      waitingPlayersGrid.appendChild(card);
    });

    // Slots vazios com borda pontilhada (preenchendo até 8 vagas)
    const maxSlots = 8;
    const emptySlots = Math.max(0, maxSlots - players.length);
    for (let i = 0; i < emptySlots; i++) {
      const emptyCard = document.createElement("div");
      emptyCard.className = "player-waiting-card slot-empty";
      emptyCard.innerHTML = `
        <div class="empty-silhouette-circle">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
          </svg>
        </div>
        <span class="empty-slot-label">Vaga livre</span>
      `;
      waitingPlayersGrid.appendChild(emptyCard);
    }
  }

  // Renderizar Placar Durante a Partida (Visual idêntico ao Drawhio da imagem)
  function renderIngameLeaderboard(players, drawerId) {
    playersList.innerHTML = "";
    if (headerPlayerCount) headerPlayerCount.textContent = players.length;
    if (ingamePlayerCount) ingamePlayerCount.textContent = `(${players.length})`;

    // Ordenar por pontuação decrescente
    const sorted = [...players].sort((a, b) => b.score - a.score);

    sorted.forEach((p, idx) => {
      const item = document.createElement("div");
      const isDrawer = p.id === drawerId;
      const isMe = p.id === socket.id;
      item.id = "leaderboard-item-" + p.id;
      item.className = "player-rank-card" + 
        (isDrawer ? " is-drawing" : "") + 
        (isMe ? " is-me" : "") +
        (p.hasGuessed ? " has-guessed" : "");

      const rankSymbol = `${idx + 1}`;
      const avatarSvg = renderAvatarSvg(p.avatar, 36);
      const drawingBadge = isDrawer ? `<span class="badge-drawing-now">Desenhando agora</span>` : "";

      let kickActionBtn = "";
      if (!isMe && !p.isBot) {
        if (isCurrentHost) {
          kickActionBtn = `
            <button type="button" class="player-kick-trigger-btn" data-kick-id="${p.id}" data-kick-name="${escapeHtml(p.name)}" title="Expulsar Jogador">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line>
              </svg>
            </button>
          `;
        } else {
          kickActionBtn = `
            <button type="button" class="player-kick-trigger-btn" data-votekick-id="${p.id}" data-votekick-name="${escapeHtml(p.name)}" title="Votar para Expulsar (Votekick)">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
              </svg>
            </button>
          `;
        }
      }

      item.innerHTML = `
        <span class="rank-badge-num">${rankSymbol}</span>
        <div class="rank-avatar-box">${avatarSvg}</div>
        <div class="rank-info">
          <div class="rank-name-row">
            <span class="rank-player-name" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</span>
            ${isMe ? '<span class="you-badge">Você</span>' : ""}
            ${kickActionBtn}
          </div>
          ${drawingBadge}
        </div>
        <div class="rank-points-col">
          <span class="rank-points-val">${p.score}</span>
          <span class="rank-points-label">pontos</span>
        </div>
      `;
      playersList.appendChild(item);
    });
  }

  // Helper para ícones temáticos de palavras e categorias
  function getWordIconSvg(word = "", category = "") {
    const norm = (word || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
    const cat = (category || "").toLowerCase().trim();

    // Palavras específicas com ícones personalizados
    if (norm === "bicicleta") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="18.5" cy="17.5" r="3.5"></circle>
        <circle cx="5.5" cy="17.5" r="3.5"></circle>
        <circle cx="15" cy="5" r="1"></circle>
        <path d="M12 17.5V14l-3-3 4-3 2 3h2"></path>
      </svg>`;
    }
    if (norm === "computador" || norm === "celular" || norm === "televisao") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2"></rect>
        <line x1="8" y1="21" x2="16" y2="21"></line>
        <line x1="12" y1="17" x2="12" y2="21"></line>
      </svg>`;
    }
    if (norm === "relogio") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="7"></circle>
        <polyline points="12 9 12 12 13.5 13.5"></polyline>
        <path d="M16.51 17.35l-.35 3.83a2 2 0 0 1-2 1.82H9.83a2 2 0 0 1-2-1.82l-.35-3.83m.01-10.7l.35-3.83A2 2 0 0 1 9.83 1h4.35a2 2 0 0 1 2 1.82l.35 3.83"></path>
      </svg>`;
    }
    if (norm === "foguete") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path>
        <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path>
      </svg>`;
    }
    if (norm === "pizza" || norm === "hamburguer" || norm === "sorvete" || norm === "bolo" || norm === "queijo") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M15 11h.01M11 15h.01M16 16h.01M2 16l20 6-6-20A20 20 0 0 0 2 16z"></path>
      </svg>`;
    }

    // Por Categoria
    // Animais: Pata de animal (como visto em CANGURU e CACHORRO na imagem)
    if (cat === "animais") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
        <circle cx="6.5" cy="8.5" r="2.25"></circle>
        <circle cx="17.5" cy="8.5" r="2.25"></circle>
        <circle cx="10" cy="5.5" r="2.25"></circle>
        <circle cx="14" cy="5.5" r="2.25"></circle>
        <path d="M12 10.5c-3.1 0-5.5 2.1-5.5 4.8 0 2.2 1.8 4.2 4.2 4.7.8.2 1.8.2 2.6 0 2.4-.5 4.2-2.5 4.2-4.7 0-2.7-2.4-4.8-5.5-4.8z"></path>
      </svg>`;
    }

    if (cat === "alimentos") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
        <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
        <line x1="6" y1="1" x2="6" y2="4"></line>
        <line x1="10" y1="1" x2="10" y2="4"></line>
        <line x1="14" y1="1" x2="14" y2="4"></line>
      </svg>`;
    }

    if (cat === "lugares") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>`;
    }

    if (cat === "profissoes") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2"></rect>
        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
      </svg>`;
    }

    if (cat === "natureza") {
      return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path>
        <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path>
      </svg>`;
    }

    // Default: Cubo / Objeto geométrico
    return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>`;
  }

  // Listener ativo para atalhos de teclado 1, 2, 3
  let activeWordChoiceListener = null;

  function hideWordSelectModal() {
    if (wordModal) wordModal.classList.add("hidden");
    if (activeWordChoiceListener) {
      window.removeEventListener("keydown", activeWordChoiceListener);
      activeWordChoiceListener = null;
    }
  }

  function hideAllGameModals() {
    hideWordSelectModal();
    if (roundEndModal) roundEndModal.classList.add("hidden");
    if (gameOverModal) gameOverModal.classList.add("hidden");
    if (settingsModal) settingsModal.classList.add("hidden");
    if (customWordsModal) customWordsModal.classList.add("hidden");
    if (publicRoomsModal) publicRoomsModal.classList.add("hidden");
    if (gameModesModal) gameModesModal.classList.add("hidden");
    if (createRoomModal) createRoomModal.classList.add("hidden");
    if (roomPasswordModal) roomPasswordModal.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");
  }

  // Modal de Escolha de Palavras (Fiel ao design moderno)
  function showWordSelectModal(choices) {
    wordModal.classList.remove("hidden");
    wordChoicesContainer.innerHTML = "";

    if (activeWordChoiceListener) {
      window.removeEventListener("keydown", activeWordChoiceListener);
      activeWordChoiceListener = null;
    }

    const selectChoice = (c) => {
      hideWordSelectModal();
      if (isLocalRoomActive && window.LocalGameRoom) {
        window.LocalGameRoom.chooseWord(c.word);
      } else {
        socket.emit("choose_word", c.word);
      }
      soundSystem.playClick();
    };

    choices.forEach((c, index) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn-word-choice";
      btn.setAttribute("data-choice-index", index + 1);

      const iconSvg = getWordIconSvg(c.word, c.category);

      btn.innerHTML = `
        <div class="word-choice-main">
          <div class="word-choice-icon">${iconSvg}</div>
          <span class="word-choice-text">${c.word.toUpperCase()}</span>
        </div>
        <span class="word-category-tag">${c.category}</span>
      `;
      btn.addEventListener("click", () => selectChoice(c));
      wordChoicesContainer.appendChild(btn);
    });

    // Registrar atalho de teclado para teclas 1, 2 e 3
    activeWordChoiceListener = (e) => {
      if (wordModal.classList.contains("hidden")) return;
      if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;

      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= choices.length) {
        e.preventDefault();
        selectChoice(choices[num - 1]);
      }
    };
    window.addEventListener("keydown", activeWordChoiceListener);
  }

  // Modal de Fim de Rodada
  socket.on("round_ended", (data) => {
    latestRoundDrawHistory = data.drawHistory || (drawingBoard ? drawingBoard.history : []);
    showRoundEndModal({
      word: data.revealedWord || "",
      category: data.hint || "Geral",
      scores: data.scores || [],
      drawHistory: latestRoundDrawHistory
    });
  });

  function showRoundEndModal(summary) {
    lastRoundSummary = summary;
    roundEndModal.classList.remove("hidden");
    roundWordReveal.textContent = (summary.word || "").toUpperCase();
    roundHintReveal.textContent = `Categoria: ${(summary.category || "Geral").toUpperCase()}`;

    // Resetar o container de Timelapse
    if (timelapseContainer) timelapseContainer.classList.add("hidden");
    if (timelapseProgressFill) timelapseProgressFill.style.width = "0%";
    if (currentTimelapsePlayer) {
      currentTimelapsePlayer.cancel();
      currentTimelapsePlayer = null;
    }

    roundScoresList.innerHTML = "";
    if (summary.scores && summary.scores.length > 0) {
      summary.scores.forEach(s => {
        const row = document.createElement("div");
        row.className = "score-gain-row";
        row.innerHTML = `
          <span>${escapeHtml(s.name)}</span>
          <span class="score-gain-plus">+${s.points || s.roundPoints || 0} pts</span>
        `;
        roundScoresList.appendChild(row);
      });
    } else {
      roundScoresList.innerHTML = `<p style="color: var(--text-dim); font-size: 0.85rem;">Nenhum jogador acertou nesta rodada.</p>`;
    }
  }

  // Reproduzir Timelapse do desenho em 5 segundos (v1.4)
  if (btnPlayTimelapse) {
    btnPlayTimelapse.addEventListener("click", () => {
      const historyToReplay = latestRoundDrawHistory && latestRoundDrawHistory.length > 0
        ? latestRoundDrawHistory
        : (drawingBoard ? drawingBoard.history : []);

      if (!historyToReplay || historyToReplay.length === 0) {
        showToast("Nenhum traço para reproduzir no timelapse.");
        return;
      }

      if (timelapseContainer) timelapseContainer.classList.remove("hidden");
      if (timelapseProgressFill) timelapseProgressFill.style.width = "0%";

      if (currentTimelapsePlayer) currentTimelapsePlayer.cancel();

      currentTimelapsePlayer = DrawingBoard.playTimelapse(
        timelapseCanvas,
        historyToReplay,
        5000,
        (progress) => {
          if (timelapseProgressFill) timelapseProgressFill.style.width = `${Math.round(progress * 100)}%`;
        },
        () => {
          showToast("Timelapse concluído!");
        }
      );
    });
  }

  // Modal de Fim de Jogo (Pódio Final & Galeria Telefone Sem Fio)
  socket.on("game_over", (data) => {
    lastTelephoneChain = data.telephoneChain || [];
    showGameOverModal(data.podium || [], lastTelephoneChain);
  });

  function showGameOverModal(podium, telephoneChain = []) {
    gameOverModal.classList.remove("hidden");
    confettiCannon.burst();
    soundSystem.playWin();

    podiumContainer.innerHTML = "";
    const spotsOrder = [1, 0, 2]; // Ordem visual do pódio: 2º lugar à esquerda, 1º no centro, 3º à direita

    spotsOrder.forEach(idx => {
      const p = podium[idx];
      if (!p) return;

      const spot = document.createElement("div");
      spot.className = `podium-spot spot-${idx + 1}`;
      const avatarSvg = renderAvatarSvg(p.avatar, 60);

      spot.innerHTML = `
        <div class="podium-avatar-box">${avatarSvg}</div>
        <div class="podium-player-name">${escapeHtml(p.name)}</div>
        <div class="podium-player-score">${p.score} pts</div>
        <div class="podium-pedestal">${idx + 1}º</div>
      `;
      podiumContainer.appendChild(spot);
    });

    if (btnViewTelephoneGallery) {
      if (telephoneChain && telephoneChain.length > 0) {
        btnViewTelephoneGallery.classList.remove("hidden");
      } else {
        btnViewTelephoneGallery.classList.add("hidden");
      }
    }
  }

  // Moderação de Sala: Ações de Expulsão e Votekick (v1.6)
  document.addEventListener("click", (e) => {
    const kickBtn = e.target.closest(".player-kick-trigger-btn");
    if (!kickBtn) return;
    const kickId = kickBtn.getAttribute("data-kick-id");
    const votekickId = kickBtn.getAttribute("data-votekick-id");
    const name = kickBtn.getAttribute("data-kick-name") || kickBtn.getAttribute("data-votekick-name") || "Jogador";

    if (kickId) {
      if (confirm(`Deseja realmente expulsar ${name} da sala?`)) {
        socket.emit("host_kick_player", { targetId: kickId });
        soundSystem.playClick();
      }
    } else if (votekickId) {
      socket.emit("votekick_start", { targetId: votekickId });
      showToast(`Votação iniciada para expulsar ${name}!`);
      soundSystem.playClick();
    }
  });

  socket.on("votekick_update", (data) => {
    if (!votekickBanner || !data) return;
    votekickBanner.classList.remove("hidden");
    if (votekickTargetName) votekickTargetName.textContent = data.targetName || "Jogador";
    if (votekickVoteCount) votekickVoteCount.textContent = data.votes || 1;
    if (votekickRequiredCount) votekickRequiredCount.textContent = data.requiredVotes || 2;
    if (votekickTimer) votekickTimer.textContent = data.timeRemaining || 20;
    if (btnVotekickYes) {
      btnVotekickYes.removeAttribute("disabled");
      btnVotekickYes.style.opacity = "1";
    }
    if (btnVotekickNo) {
      btnVotekickNo.removeAttribute("disabled");
      btnVotekickNo.style.opacity = "1";
    }
  });

  socket.on("votekick_timer_tick", (data) => {
    if (votekickTimer && data) {
      votekickTimer.textContent = data.timeRemaining;
    }
  });

  socket.on("votekick_ended", (data) => {
    if (votekickBanner) votekickBanner.classList.add("hidden");
    if (data && data.success) {
      showToast(`${data.targetName} foi expulso pela maioria dos votos!`);
    } else if (data && data.reason) {
      showToast(data.reason);
    }
  });

  socket.on("player_kicked", (data) => {
    alert(data && data.reason ? data.reason : "Você foi desconectado da sala.");
    safeSessionRemove("drawhio_last_room");
    window.location.href = "/";
  });

  if (btnVotekickYes) {
    btnVotekickYes.addEventListener("click", () => {
      socket.emit("votekick_vote", { voteYes: true });
      btnVotekickYes.style.opacity = "0.5";
      btnVotekickYes.setAttribute("disabled", "true");
      soundSystem.playClick();
    });
  }

  if (btnVotekickNo) {
    btnVotekickNo.addEventListener("click", () => {
      socket.emit("votekick_vote", { voteYes: false });
      btnVotekickNo.style.opacity = "0.5";
      btnVotekickNo.setAttribute("disabled", "true");
      soundSystem.playClick();
    });
  }

  // Animação Flutuante de Pontuação nos Acertos (v1.6)
  socket.on("player_guessed", (data) => {
    if (!data) return;
    if (data.playerId === socket.id) {
      soundSystem.playCorrect();
      confettiCannon.fireLeft();
      confettiCannon.fireRight();
    }

    const card = document.getElementById("leaderboard-item-" + data.playerId);
    if (card) {
      const tag = document.createElement("div");
      tag.className = "floating-score-tag" + (data.isFirstGuesser ? " first-place" : "");
      tag.textContent = data.isFirstGuesser ? `1º! +${data.points}` : `+${data.points}`;
      card.style.position = "relative";
      card.appendChild(tag);
      setTimeout(() => tag.remove(), 1800);

      const valEl = card.querySelector(".rank-points-val");
      if (valEl && typeof data.score === "number") {
        valEl.textContent = data.score;
      }
    }

    // Atualização em tempo real da pontuação do desenhista (+2 pts por acerto)
    if (data.drawerId && typeof data.drawerScore === "number") {
      const drawerCard = document.getElementById("leaderboard-item-" + data.drawerId);
      if (drawerCard) {
        const drawerValEl = drawerCard.querySelector(".rank-points-val");
        if (drawerValEl) {
          drawerValEl.textContent = data.drawerScore;
        }
        const drawerTag = document.createElement("div");
        drawerTag.className = "floating-score-tag drawer-points";
        drawerTag.textContent = "+2";
        drawerCard.style.position = "relative";
        drawerCard.appendChild(drawerTag);
        setTimeout(() => drawerTag.remove(), 1800);
      }
    }
  });

  // Exportação HD no Pódio (v1.6)
  if (btnExportPodiumHd) {
    btnExportPodiumHd.addEventListener("click", () => {
      const history = (drawingBoard && drawingBoard.history && drawingBoard.history.length > 0)
        ? drawingBoard.history
        : (lastRoundSummary && lastRoundSummary.drawHistory ? lastRoundSummary.drawHistory : []);
      const title = (lastRoundSummary && lastRoundSummary.word) ? lastRoundSummary.word : "Drawhio";
      const author = (lastRoundSummary && lastRoundSummary.drawerName) ? lastRoundSummary.drawerName : "Artista";

      const exporter = window.DrawingBoard.exportFramedDrawing(history, { title, author });
      exporter.download(`drawhio_${title.toLowerCase().replace(/\s+/g, "_")}.png`);
      showToast("Arte HD com moldura Drawhio baixada com sucesso!");
    });
  }

  if (btnCopyPodiumHd) {
    btnCopyPodiumHd.addEventListener("click", async () => {
      const history = (drawingBoard && drawingBoard.history && drawingBoard.history.length > 0)
        ? drawingBoard.history
        : (lastRoundSummary && lastRoundSummary.drawHistory ? lastRoundSummary.drawHistory : []);
      const title = (lastRoundSummary && lastRoundSummary.word) ? lastRoundSummary.word : "Drawhio";
      const author = (lastRoundSummary && lastRoundSummary.drawerName) ? lastRoundSummary.drawerName : "Artista";

      const exporter = window.DrawingBoard.exportFramedDrawing(history, { title, author });
      try {
        await exporter.copyToClipboard();
        showToast("Imagem copiada! Cole no WhatsApp ou Discord.");
      } catch (err) {
        showToast("Não foi possível copiar. Use 'Baixar Arte HD'.");
      }
    });
  }

  // Galeria de Evolução do Telefone Sem Fio (v1.4)
  function renderTelephoneEvolution(chain) {
    if (!telephoneEvolutionContainer) return;
    telephoneEvolutionContainer.innerHTML = "";

    if (!chain || chain.length === 0) {
      telephoneEvolutionContainer.innerHTML = "<p style='color: #64748B;'>Nenhum passo registrado nesta partida.</p>";
      return;
    }

    chain.forEach((step, idx) => {
      const card = document.createElement("div");
      card.className = "telephone-step-card";

      if (step.type === "phrase") {
        card.innerHTML = `
          <div class="telephone-step-header">
            <span class="telephone-step-author">${escapeHtml(step.author || "Palavra Secreta")}</span>
            <span class="telephone-step-type-badge badge-phrase">Passo ${idx + 1}: Palavra</span>
          </div>
          <div class="telephone-step-content-text">"${escapeHtml(step.text || "")}"</div>
        `;
      } else if (step.type === "draw") {
        card.innerHTML = `
          <div class="telephone-step-header">
            <span class="telephone-step-author">Desenho feito por: <strong>${escapeHtml(step.author || "Desenhista")}</strong></span>
            <span class="telephone-step-type-badge badge-draw">Passo ${idx + 1}: Desenho</span>
          </div>
          <div class="telephone-step-canvas-wrap">
            <canvas width="440" height="264" class="telephone-history-canvas" data-index="${idx}"></canvas>
          </div>
        `;
      } else if (step.type === "guess") {
        const resultBadge = step.isCorrect ? "badge-guess" : "badge-phrase";
        const resultText = step.isCorrect ? "Acertou!" : "Palpite:";
        card.innerHTML = `
          <div class="telephone-step-header">
            <span class="telephone-step-author">${escapeHtml(step.author || "Jogador")}</span>
            <span class="telephone-step-type-badge ${resultBadge}">${resultText}</span>
          </div>
          <div class="telephone-step-content-text">"${escapeHtml(step.text || "")}"</div>
        `;
      }

      telephoneEvolutionContainer.appendChild(card);
    });

    // Renderizar os desenhos nos canvases dos steps de tipo "draw"
    setTimeout(() => {
      const canvases = telephoneEvolutionContainer.querySelectorAll(".telephone-history-canvas");
      canvases.forEach(cnv => {
        const stepIdx = parseInt(cnv.getAttribute("data-index"), 10);
        const stepData = chain[stepIdx];
        if (stepData && Array.isArray(stepData.history)) {
          DrawingBoard.playTimelapse(cnv, stepData.history, 0);
        }
      });
    }, 60);
  }

  if (btnViewTelephoneGallery) {
    btnViewTelephoneGallery.addEventListener("click", () => {
      renderTelephoneEvolution(lastTelephoneChain);
      if (telephoneGalleryModal) telephoneGalleryModal.classList.remove("hidden");
      soundSystem.playClick();
    });
  }

  if (btnCloseTelephoneModal) {
    btnCloseTelephoneModal.addEventListener("click", () => {
      if (telephoneGalleryModal) telephoneGalleryModal.classList.add("hidden");
      soundSystem.playClick();
    });
  }

  if (btnConfirmTelephoneModal) {
    btnConfirmTelephoneModal.addEventListener("click", () => {
      if (telephoneGalleryModal) telephoneGalleryModal.classList.add("hidden");
      soundSystem.playClick();
    });
  }

  // =========================================================
  // GARTIC PHONE: MODO TELEFONE SEM FIO (v1.4.1)
  // =========================================================
  let currentAlbumBooks = [];
  let currentAlbumBookIdx = 0;
  let currentAlbumStepIdx = 0;

  if (telefonePromptInput && telefonePromptCharCount) {
    telefonePromptInput.addEventListener("input", () => {
      telefonePromptCharCount.textContent = `${telefonePromptInput.value.length}/60`;
    });
  }

  if (telefoneDescribeInput && telefoneDescribeCharCount) {
    telefoneDescribeInput.addEventListener("input", () => {
      telefoneDescribeCharCount.textContent = `${telefoneDescribeInput.value.length}/60`;
    });
  }

  if (formTelefonePrompt) {
    formTelefonePrompt.addEventListener("submit", (e) => {
      e.preventDefault();
      const prompt = telefonePromptInput ? telefonePromptInput.value.trim() : "";
      if (!prompt) return;
      socket.emit("telefone_submit_prompt", { prompt });
      if (btnSubmitTelefonePrompt) {
        btnSubmitTelefonePrompt.setAttribute("disabled", "true");
        btnSubmitTelefonePrompt.style.opacity = "0.5";
      }
      if (telefonePromptWaitingStatus) {
        telefonePromptWaitingStatus.classList.remove("hidden");
      }
    });
  }

  if (btnSubmitTelefoneDraw) {
    btnSubmitTelefoneDraw.addEventListener("click", () => {
      const history = drawingBoard ? drawingBoard.history : [];
      socket.emit("telefone_submit_draw", { drawHistory: history });
      btnSubmitTelefoneDraw.setAttribute("disabled", "true");
      btnSubmitTelefoneDraw.classList.add("submitted");
      const span = btnSubmitTelefoneDraw.querySelector("span");
      if (span) span.textContent = "Desenho Enviado! ✓";
    });
  }

  if (formTelefoneDescribe) {
    formTelefoneDescribe.addEventListener("submit", (e) => {
      e.preventDefault();
      const guess = telefoneDescribeInput ? telefoneDescribeInput.value.trim() : "";
      if (!guess) return;
      socket.emit("telefone_submit_describe", { guess });
      if (btnSubmitTelefoneDescribe) {
        btnSubmitTelefoneDescribe.setAttribute("disabled", "true");
        btnSubmitTelefoneDescribe.style.opacity = "0.5";
      }
      if (telefoneDescribeWaitingStatus) {
        telefoneDescribeWaitingStatus.classList.remove("hidden");
      }
    });
  }

  function renderAlbumSlide(bookIndex, stepIndex) {
    currentAlbumBookIdx = bookIndex;
    currentAlbumStepIdx = stepIndex;
    if (!currentAlbumBooks || currentAlbumBooks.length === 0) return;

    const book = currentAlbumBooks[bookIndex];
    if (!book) return;

    if (albumOwnerTitle) {
      albumOwnerTitle.textContent = `Livro de ${book.bookOwnerName}`;
    }
    if (albumProgressSubtitle) {
      albumProgressSubtitle.textContent = `Álbum ${bookIndex + 1} de ${currentAlbumBooks.length} • Passo ${stepIndex + 1} de ${book.steps.length}`;
    }

    const step = book.steps[stepIndex];
    if (!step || !telefoneAlbumStage) return;

    telefoneAlbumStage.innerHTML = "";

    const card = document.createElement("div");
    card.className = "album-slide-card";

    let stepTagHtml = "";
    let stepContentHtml = "";

    if (step.type === "prompt") {
      stepTagHtml = `<span class="album-step-tag tag-prompt">1. Frase Inicial</span>`;
      stepContentHtml = `
        <div class="album-phrase-content">
          "${escapeHtml(step.text)}"
        </div>
      `;
    } else if (step.type === "draw") {
      stepTagHtml = `<span class="album-step-tag tag-draw">2. Desenho</span>`;
      stepContentHtml = `
        <div class="album-canvas-container">
          <canvas id="album-current-canvas" width="600" height="360"></canvas>
        </div>
        <div style="display: flex; justify-content: center; margin-top: 14px;">
          <button type="button" id="btn-album-timelapse-replay" class="btn-timelapse-pill">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
            <span>Reproduzir Timelapse</span>
          </button>
        </div>
      `;
    } else if (step.type === "describe") {
      stepTagHtml = `<span class="album-step-tag tag-describe">3. Palpite Final</span>`;
      stepContentHtml = `
        <div class="album-phrase-content" style="color: #059669;">
          "${escapeHtml(step.text)}"
        </div>
      `;
    }

    const authorAvatarSrc = getAvatarSrc(step.authorAvatar);

    card.innerHTML = `
      <div class="album-slide-meta">
        <div class="album-author-badge">
          <img src="${authorAvatarSrc}" alt="${escapeHtml(step.authorName)}" class="album-author-avatar">
          <span class="album-author-name">${escapeHtml(step.authorName)}</span>
        </div>
        ${stepTagHtml}
      </div>
      ${stepContentHtml}
    `;

    telefoneAlbumStage.appendChild(card);

    if (step.type === "draw") {
      const cnv = document.getElementById("album-current-canvas");
      if (cnv && window.DrawingBoard) {
        window.DrawingBoard.renderStatic(cnv, step.drawHistory);
      }
      const replayBtn = document.getElementById("btn-album-timelapse-replay");
      if (replayBtn && cnv && window.DrawingBoard) {
        replayBtn.addEventListener("click", () => {
          window.DrawingBoard.playTimelapse(cnv, step.drawHistory, 2500);
        });
      }
    }

    if (isCurrentHost) {
      if (btnAlbumPrevSlide) btnAlbumPrevSlide.disabled = (bookIndex === 0 && stepIndex === 0);
      const isLastStepOfAll = (bookIndex === currentAlbumBooks.length - 1 && stepIndex === book.steps.length - 1);
      if (labelAlbumNext) {
        labelAlbumNext.textContent = isLastStepOfAll ? "Finalizar Álbum" : "Próximo Passo";
      }
    }
  }

  // Socket: Etapa 1 - Prompt
  socket.on("telefone_phase_prompt", (data) => {
    hideAllGameModals();
    document.body.classList.add("telefone-mode-active");
    if (drawingToolbar) drawingToolbar.classList.add("hidden");
    if (gameScreen) gameScreen.classList.add("hidden");
    if (waitingRoomScreen) waitingRoomScreen.classList.add("hidden");
    if (lobbyScreen) lobbyScreen.classList.add("hidden");
    if (telefoneDescribeScreen) telefoneDescribeScreen.classList.add("hidden");
    if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");

    if (telefonePromptScreen) {
      telefonePromptScreen.classList.remove("hidden");
      if (telefonePromptInput) {
        telefonePromptInput.value = "";
        telefonePromptInput.removeAttribute("disabled");
        telefonePromptInput.focus();
      }
      if (telefonePromptCharCount) {
        telefonePromptCharCount.textContent = "0/60";
      }
      if (btnSubmitTelefonePrompt) {
        btnSubmitTelefonePrompt.removeAttribute("disabled");
        btnSubmitTelefonePrompt.style.opacity = "1";
      }
      if (telefonePromptWaitingStatus) {
        telefonePromptWaitingStatus.classList.add("hidden");
      }
      if (telefonePromptTimer && data && data.timeRemaining) {
        telefonePromptTimer.textContent = `${data.timeRemaining}s`;
      }
    }
  });

  // Socket: Etapa 2 - Desenhar
  socket.on("telefone_phase_draw", (data) => {
    hideAllGameModals();
    document.body.classList.add("telefone-mode-active");
    if (telefonePromptScreen) telefonePromptScreen.classList.add("hidden");
    if (telefoneDescribeScreen) telefoneDescribeScreen.classList.add("hidden");
    if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");

    if (gameScreen) gameScreen.classList.remove("hidden");
    document.body.classList.add("in-game-bg");

    if (standardCanvasStatusBar) standardCanvasStatusBar.classList.add("hidden");
    if (telefoneDrawMissionBar) {
      telefoneDrawMissionBar.classList.remove("hidden");
      if (telefoneDrawMissionText && data) {
        telefoneDrawMissionText.textContent = `"${data.promptToDraw || "Desenho Livre"}"`;
      }
      if (telefoneDrawTimer && data && data.timeRemaining) {
        telefoneDrawTimer.textContent = `${data.timeRemaining}s`;
      }
      if (btnSubmitTelefoneDraw) {
        btnSubmitTelefoneDraw.removeAttribute("disabled");
        btnSubmitTelefoneDraw.classList.remove("submitted");
        const span = btnSubmitTelefoneDraw.querySelector("span");
        if (span) span.textContent = "Terminei o Desenho";
      }
    }

    // Exibir barra de ferramentas com todas as cores e roda de cores
    if (drawingToolbar) {
      drawingToolbar.classList.remove("hidden");
    }

    if (drawingBoard) {
      drawingBoard.clearCanvas(false);
      drawingBoard.setInteractive(true);
      drawingBoard.setTool("brush");
      drawingBoard.history = [];
    }

    // Selecionar visualmente ferramenta de pincel
    document.querySelectorAll(".draw-tool-btn").forEach(btn => btn.classList.remove("active"));
    const btnBrush = document.getElementById("tool-brush");
    if (btnBrush) btnBrush.classList.add("active");
  });

  // Socket: Etapa 3 - Descrever
  socket.on("telefone_phase_describe", (data) => {
    hideAllGameModals();
    document.body.classList.add("telefone-mode-active");
    if (drawingToolbar) drawingToolbar.classList.add("hidden");
    if (telefonePromptScreen) telefonePromptScreen.classList.add("hidden");
    if (gameScreen) gameScreen.classList.add("hidden");
    if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");

    if (telefoneDescribeScreen) {
      telefoneDescribeScreen.classList.remove("hidden");
      if (telefoneDescribeInput) {
        telefoneDescribeInput.value = "";
        telefoneDescribeInput.removeAttribute("disabled");
        telefoneDescribeInput.focus();
      }
      if (telefoneDescribeCharCount) {
        telefoneDescribeCharCount.textContent = "0/60";
      }
      if (btnSubmitTelefoneDescribe) {
        btnSubmitTelefoneDescribe.removeAttribute("disabled");
        btnSubmitTelefoneDescribe.style.opacity = "1";
      }
      if (telefoneDescribeWaitingStatus) {
        telefoneDescribeWaitingStatus.classList.add("hidden");
      }
      if (telefoneDescribeTimer && data && data.timeRemaining) {
        telefoneDescribeTimer.textContent = `${data.timeRemaining}s`;
      }

      if (telefoneDescribePreviewCanvas && window.DrawingBoard) {
        window.DrawingBoard.renderStatic(telefoneDescribePreviewCanvas, data ? data.drawHistory : []);
      }
    }
  });

  // Socket: Etapa 4 - Álbum Sincronizado
  socket.on("telefone_album_start", (data) => {
    hideAllGameModals();
    document.body.classList.add("telefone-mode-active");
    if (drawingToolbar) drawingToolbar.classList.add("hidden");
    if (telefonePromptScreen) telefonePromptScreen.classList.add("hidden");
    if (gameScreen) gameScreen.classList.add("hidden");
    if (telefoneDescribeScreen) telefoneDescribeScreen.classList.add("hidden");
    if (waitingRoomScreen) waitingRoomScreen.classList.add("hidden");
    if (telefoneFinalGallery) telefoneFinalGallery.classList.add("hidden");

    if (telefoneAlbumScreen) {
      telefoneAlbumScreen.classList.remove("hidden");
      currentAlbumBooks = (data && data.books) ? data.books : [];

      if (isCurrentHost) {
        if (albumHostControls) albumHostControls.classList.remove("hidden");
        if (albumGuestNotice) albumGuestNotice.classList.add("hidden");
      } else {
        if (albumHostControls) albumHostControls.classList.add("hidden");
        if (albumGuestNotice) albumGuestNotice.classList.remove("hidden");
      }

      renderAlbumSlide(data ? (data.currentBookIndex || 0) : 0, data ? (data.currentStepIndex || 0) : 0);
    }
  });

  socket.on("telefone_slide_update", (data) => {
    if (data) {
      renderAlbumSlide(data.currentBookIndex, data.currentStepIndex);
    }
  });

  // Socket: Etapa 5 - Fim do Álbum & Galeria Completa (Estilo Gartic Phone)
  socket.on("telefone_album_finished", (data) => {
    if (data && data.books && Array.isArray(data.books)) {
      currentAlbumBooks = data.books;
    }
    showToast("Exibição finalizada! Veja a galeria completa.");
    if (telefoneAlbumScreen) telefoneAlbumScreen.classList.add("hidden");

    renderTelefoneFinalGallery(currentAlbumBooks);
  });

  function renderTelefoneFinalGallery(books) {
    if (!telefoneFinalGallery || !recapBooksContainer) return;
    telefoneFinalGallery.classList.remove("hidden");

    if (isCurrentHost) {
      if (recapHostActions) recapHostActions.classList.remove("hidden");
      if (recapGuestNotice) recapGuestNotice.classList.add("hidden");
    } else {
      if (recapHostActions) recapHostActions.classList.add("hidden");
      if (recapGuestNotice) recapGuestNotice.classList.remove("hidden");
    }

    recapBooksContainer.innerHTML = "";

    if (!Array.isArray(books) || books.length === 0) {
      recapBooksContainer.innerHTML = `<div class="recap-empty-msg" style="text-align: center; color: var(--text-muted); padding: 40px;">Nenhum álbum registrado nesta partida.</div>`;
      return;
    }

    books.forEach((book, bIdx) => {
      const bookCard = document.createElement("div");
      bookCard.className = "recap-book-entry";

      const header = document.createElement("div");
      header.className = "recap-book-header";
      const owner = book.bookOwnerName || book.ownerName || "Jogador";
      header.innerHTML = `
        <div class="recap-book-tag">História #${bIdx + 1}</div>
        <div class="recap-author-info">
          <span class="recap-book-label">Começou com</span>
          <strong class="recap-book-owner">${escapeHtml(owner)}</strong>
        </div>
      `;
      bookCard.appendChild(header);

      const timeline = document.createElement("div");
      timeline.className = "recap-steps-timeline";

      if (Array.isArray(book.steps)) {
        book.steps.forEach((step, sIdx) => {
          const stepItem = document.createElement("div");
          stepItem.className = `recap-step-item recap-step-${step.type}`;

          if (step.type === "prompt") {
            stepItem.innerHTML = `
              <div class="recap-step-badge">1. Frase Inicial</div>
              <div class="recap-step-author">Por: <strong>${escapeHtml(step.authorName || "Jogador")}</strong></div>
              <div class="recap-prompt-bubble">"${escapeHtml(step.text || "")}"</div>
            `;
          } else if (step.type === "draw") {
            const wrap = document.createElement("div");
            wrap.innerHTML = `
              <div class="recap-step-badge">2. Desenho</div>
              <div class="recap-step-author">Por: <strong>${escapeHtml(step.authorName || "Jogador")}</strong></div>
              <div class="recap-canvas-wrap">
                <canvas class="recap-thumb-canvas" width="600" height="360"></canvas>
                <div class="recap-canvas-actions">
                  <button type="button" class="btn-download-drawing" title="Baixar Desenho PNG">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                      <polyline points="7 10 12 15 17 10"></polyline>
                      <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                    <span>Baixar Desenho</span>
                  </button>
                </div>
              </div>
            `;
            stepItem.appendChild(wrap);

            const canvas = wrap.querySelector("canvas");
            if (canvas && window.DrawingBoard) {
              window.DrawingBoard.renderStatic(canvas, step.drawHistory || []);
            }

            const btnDownload = wrap.querySelector(".btn-download-drawing");
            if (btnDownload && canvas) {
              btnDownload.addEventListener("click", () => {
                const a = document.createElement("a");
                a.download = `desenho_${escapeHtml(step.authorName || "drawhio")}.png`;
                a.href = canvas.toDataURL("image/png");
                a.click();
              });
            }
          } else if (step.type === "describe") {
            stepItem.innerHTML = `
              <div class="recap-step-badge">3. Palpite Final</div>
              <div class="recap-step-author">Por: <strong>${escapeHtml(step.authorName || "Jogador")}</strong></div>
              <div class="recap-describe-bubble">"${escapeHtml(step.text || "")}"</div>
            `;
          }

          timeline.appendChild(stepItem);
        });
      }

      bookCard.appendChild(timeline);
      recapBooksContainer.appendChild(bookCard);
    });
  }

  socket.on("telefone_timer_update", (data) => {
    if (!data) return;
    if (telefonePromptTimer) telefonePromptTimer.textContent = `${data.timeRemaining}s`;
    if (telefoneDrawTimer) telefoneDrawTimer.textContent = `${data.timeRemaining}s`;
    if (telefoneDescribeTimer) telefoneDescribeTimer.textContent = `${data.timeRemaining}s`;
  });

  // Reações no Álbum (Ícones SVG próprios, sem emojis)
  document.querySelectorAll(".btn-album-reaction").forEach(btn => {
    btn.addEventListener("click", () => {
      const reaction = btn.getAttribute("data-reaction");
      socket.emit("album_reaction", { reaction });
    });
  });

  const reactionSvgMap = {
    laugh: `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#F59E0B" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>`,
    heart: `<svg viewBox="0 0 24 24" width="22" height="22" fill="#EF4444" stroke="#EF4444" stroke-width="1"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`,
    idea: `<svg viewBox="0 0 24 24" width="22" height="22" fill="#FBBF24" stroke="#F59E0B" stroke-width="1.8" stroke-linecap="round"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-7 7c0 2.38 1.19 4.47 3 5.74V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.26c1.81-1.27 3-3.36 3-5.74a7 7 0 0 0-7-7z"/></svg>`,
    star: `<svg viewBox="0 0 24 24" width="22" height="22" fill="#FBBF24" stroke="#D97706" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    thumbsup: `<svg viewBox="0 0 24 24" width="22" height="22" fill="#3B82F6" stroke="#2563EB" stroke-width="1.5"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>`
  };

  socket.on("album_reaction_received", (data) => {
    if (!telefoneAlbumStage) return;
    const svgIcon = reactionSvgMap[data.reaction] || reactionSvgMap.star;
    spawnFloatingAlbumReaction(svgIcon, data.playerName);
  });

  function spawnFloatingAlbumReaction(svgMarkup, name) {
    const bubble = document.createElement("div");
    bubble.className = "floating-album-reaction-bubble";
    bubble.innerHTML = `<div class="reaction-svg-icon" style="display:flex;align-items:center;">${svgMarkup}</div><small style="font-size: 0.72rem; color: #FFFFFF; font-weight: 700; margin-left: 6px;">${escapeHtml(name)}</small>`;
    bubble.style.position = "absolute";
    bubble.style.left = `${20 + Math.random() * 60}%`;
    bubble.style.bottom = "20px";
    bubble.style.zIndex = "1600";
    bubble.style.pointerEvents = "none";
    bubble.style.background = "rgba(15, 23, 42, 0.85)";
    bubble.style.border = "1px solid rgba(255, 255, 255, 0.15)";
    bubble.style.backdropFilter = "blur(8px)";
    bubble.style.padding = "6px 12px";
    bubble.style.borderRadius = "9999px";
    bubble.style.display = "flex";
    bubble.style.alignItems = "center";
    bubble.style.boxShadow = "0 8px 24px rgba(0,0,0,0.3)";
    bubble.style.transition = "all 2s ease";
    telefoneAlbumStage.appendChild(bubble);

    requestAnimationFrame(() => {
      bubble.style.transform = `translateY(-180px) scale(1.1)`;
      bubble.style.opacity = "0";
    });

    setTimeout(() => bubble.remove(), 2100);
  }

  if (btnAlbumNextSlide) {
    btnAlbumNextSlide.addEventListener("click", () => {
      socket.emit("telefone_next_slide");
    });
  }

  if (btnAlbumPrevSlide) {
    btnAlbumPrevSlide.addEventListener("click", () => {
      socket.emit("telefone_prev_slide");
    });
  }

  if (btnAlbumFinish) {
    btnAlbumFinish.addEventListener("click", () => {
      socket.emit("telefone_finish_album");
    });
  }

  // Ações da Galeria Final Recap (v1.5)
  if (btnRecapPlayAgain) {
    btnRecapPlayAgain.addEventListener("click", () => {
      socket.emit("start_game");
      soundSystem.playClick();
    });
  }

  if (btnRecapBackLobby) {
    btnRecapBackLobby.addEventListener("click", () => {
      socket.emit("telefone_finish_album");
      soundSystem.playClick();
    });
  }

  btnPlayAgain.addEventListener("click", () => {
    if (isLocalRoomActive && window.LocalGameRoom) {
      window.LocalGameRoom.restartToLobby();
      if (gameOverScreen) gameOverScreen.classList.add("hidden");
      showWaitingRoom();
    } else {
      socket.emit("restart_game");
    }
    soundSystem.playClick();
  });

  // =========================================================
  // SUPORTE A HOSPEDAGEM HTML ESTÁTICA & CONFIGURAÇÃO DE SERVIDOR
  // =========================================================
  function updateServerStatusUI(connected, text) {
    if (!serverStatusPill || !serverStatusText) return;
    serverStatusPill.className = "server-status-pill " + (connected ? "status-connected" : "status-disconnected");
    serverStatusText.textContent = text || (connected ? "Conectado" : "Desconectado");
  }

  if (settingServerUrl) {
    settingServerUrl.value = targetServerUrl;
  }

  socket.on("connect", () => {
    updateServerStatusUI(true, `Conectado: ${targetServerUrl}`);
    if (htmlHostServerAlert) htmlHostServerAlert.classList.add("hidden");
  });

  socket.on("connect_error", () => {
    updateServerStatusUI(false, "Falha na conexão com o servidor backend");
    if (!isSameOrigin || (window.location.hostname !== "localhost" && window.location.hostname !== "127.0.0.1")) {
      if (htmlHostServerAlert) htmlHostServerAlert.classList.remove("hidden");
    }
  });

  socket.on("disconnect", () => {
    updateServerStatusUI(false, "Desconectado do servidor");
  });

  if (btnAlertConfigureServer) {
    btnAlertConfigureServer.addEventListener("click", () => {
      if (settingsModal) settingsModal.classList.remove("hidden");
      if (settingServerUrl) settingServerUrl.focus();
    });
  }

  if (btnAlertDismiss) {
    btnAlertDismiss.addEventListener("click", () => {
      if (htmlHostServerAlert) htmlHostServerAlert.classList.add("hidden");
    });
  }

  if (btnSaveServerConn) {
    btnSaveServerConn.addEventListener("click", () => {
      const newUrl = (settingServerUrl ? settingServerUrl.value : "").trim();
      if (!newUrl) {
        localStorage.removeItem("drawhio_custom_server_url");
        showToast("Configuração resetada para origem padrão. Recarregando...");
      } else {
        localStorage.setItem("drawhio_custom_server_url", newUrl);
        showToast("Servidor salvo com sucesso! Recarregando conexão...");
      }
      setTimeout(() => window.location.reload(), 600);
    });
  }

  if (btnTestServerConn) {
    btnTestServerConn.addEventListener("click", async () => {
      const urlToTest = (settingServerUrl ? settingServerUrl.value : targetServerUrl).trim().replace(/\/$/, "");
      if (!urlToTest) {
        showToast("Por favor, digite a URL do servidor para testar.");
        return;
      }
      btnTestServerConn.textContent = "Testando...";
      btnTestServerConn.disabled = true;
      try {
        const res = await fetch(`${urlToTest}/api/health`, { method: "GET", mode: "cors" });
        if (res.ok) {
          const data = await res.json();
          showToast(`🟢 Conexão bem-sucedida com servidor ${data.app || "Drawhio"}!`);
          updateServerStatusUI(true, `Conectado: ${urlToTest}`);
        } else {
          showToast(`⚠️ Servidor respondeu com código ${res.status}.`);
        }
      } catch (err) {
        showToast("🔴 Falha ao conectar. Verifique a URL e se o servidor Node está rodando.");
        updateServerStatusUI(false, "Servidor inalcançável");
      } finally {
        btnTestServerConn.textContent = "Testar";
        btnTestServerConn.disabled = false;
      }
    });
  }

  // Ações de Sair da Sala / Lobby
  if (btnLeaveLobby) {
    btnLeaveLobby.addEventListener("click", () => {
      safeSessionRemove("drawhio_last_room");
      currentRoom = null;
      if (isLocalRoomActive && window.LocalGameRoom) {
        window.LocalGameRoom.reset();
        isLocalRoomActive = false;
      }
      socket.emit("leave_room");
      window.location.reload();
    });
  }

  if (btnLeaveRoom) {
    btnLeaveRoom.addEventListener("click", () => {
      if (isSoloMode) {
        isSoloMode = false;
        if (gameScreen) gameScreen.classList.add("hidden");
        if (lobbyScreen) lobbyScreen.classList.remove("hidden");
        document.body.classList.remove("in-game-bg");
        return;
      }
      safeSessionRemove("drawhio_last_room");
      currentRoom = null;
      if (isLocalRoomActive && window.LocalGameRoom) {
        window.LocalGameRoom.reset();
        isLocalRoomActive = false;
      }
      socket.emit("leave_room");
      window.location.reload();
    });
  }

  // =========================================================
  // MODO TREINO SOLO / DESENHO LIVRE (OFFLINE / SEM SERVIDOR)
  // =========================================================
  let isSoloMode = false;
  const soloThemes = [
    "Um Pinguim Astronauta",
    "Gato Ninja com Katana",
    "Castelo Mágico no Céu",
    "Dragão tomando Sorvete",
    "Carro Voador Futurista",
    "Robô tocando Violão",
    "Pizza Gigante no Espaço",
    "Tubarão com Óculos Escuros",
    "Dinossauro andando de Patins",
    "Cachorro Detetive procurando Ossos"
  ];

  function startSoloDrawMode() {
    isSoloMode = true;
    const currentTheme = soloThemes[Math.floor(Math.random() * soloThemes.length)];

    if (lobbyScreen) lobbyScreen.classList.add("hidden");
    if (waitingRoomScreen) waitingRoomScreen.classList.add("hidden");
    if (gameScreen) gameScreen.classList.remove("hidden");
    document.body.classList.add("in-game-bg");

    isCurrentDrawer = true;
    myPlayerId = "solo-artist";

    if (!drawingBoard) {
      drawingBoard = new DrawingBoard("drawing-canvas");
    }
    drawingBoard.enable();
    drawingBoard.clearCanvas(false);

    if (wordDisplay) {
      wordDisplay.textContent = currentTheme;
    }
    if (timerDisplay) {
      timerDisplay.textContent = "Livre";
    }

    const toolsDock = document.getElementById("canvas-tools-dock");
    if (toolsDock) toolsDock.classList.remove("hidden");

    addChatMessage("system", `🎨 Bem-vindo ao Modo Treino Solo! Tema sugerido: "${currentTheme}". Você pode desenhar livremente com todas as ferramentas e exportar sua arte em HD!`);
    showToast(`Modo Treino iniciado: Tema "${currentTheme}"!`);
  }

  if (btnOpenSoloDraw) {
    btnOpenSoloDraw.addEventListener("click", startSoloDrawMode);
  }
  if (btnAlertSoloMode) {
    btnAlertSoloMode.addEventListener("click", startSoloDrawMode);
  }

});

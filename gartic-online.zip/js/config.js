/**
 * =========================================================
 * DRAWHIO - CONFIGURAÇÃO DE HOSPEDAGEM (SITE HTML)
 * =========================================================
 * 
 * Se você estiver hospedando os arquivos deste site em uma
 * hospedagem HTML estática (Hostinger, cPanel public_html,
 * GitHub Pages, Netlify, Vercel, InfinityFree, Locaweb, etc.),
 * você pode definir aqui a URL pública do seu servidor Node.js.
 * 
 * EXEMPLO DE USO:
 *   SERVER_URL: "https://tough-walrus-25.loca.lt"
 * 
 * NOTAS:
 * - Se deixar "" (vazio), o Drawhio tentará conectar na mesma
 *   origem (se o Node estiver servindo o HTML) ou no endereço
 *   configurado pelo jogador no menu de Configurações do jogo.
 * - Os jogadores também podem alterar a URL do servidor diretamente
 *   na interface através do menu "Configurações" -> "Servidor Backend".
 */

window.DRAWHIO_CONFIG = {
  // URL pública do servidor Node.js backend (gerada pelo LIGAR_MULTIPLAYER_ONLINE.bat)
  SERVER_URL: "https://tough-walrus-25.loca.lt",

  // Ativar Modo Treino Solo / Desenho Livre quando offline ou sem servidor
  ENABLE_OFFLINE_SOLO: true,

  // Versão da aplicação
  VERSION: "1.6.0"
};
